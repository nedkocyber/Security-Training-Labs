<?php
session_start();

ini_set('display_errors', 1);
error_reporting(E_ALL);

$conn = new mysqli(
    "mysql",
    "MegaAdmin",
    "CantGuessTh!sPass",
    "petstore"
);

if ($conn->connect_error) {
    die("DB connection failed");
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

