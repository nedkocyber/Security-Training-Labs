<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user'];
$fname = $_SESSION['fname'] ?? $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard</title>

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #eef2f1;
}
header {
    background: #1f4037;
    color: white;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
nav a {
    color: white;
    margin-left: 15px;
    text-decoration: none;
    font-weight: bold;
}
nav a:hover {
    text-decoration: underline;
}
.container {
    padding: 40px;
}
.hero {
    background: linear-gradient(135deg, #1f4037, #99f2c8);
    color: white;
    padding: 30px;
    border-radius: 18px;
    margin-bottom: 30px;
}
.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
}
.card {
    background: white;
    padding: 25px;
    border-radius: 14px;
    box-shadow: 0 6px 18px rgba(0,0,0,0.12);
}
.card a {
    display: inline-block;
    margin-top: 10px;
    background: #1f4037;
    color: white;
    padding: 8px 14px;
    border-radius: 6px;
    text-decoration: none;
}
.card a:hover {
    background: #16352e;
}
</style>
</head>

<body>

<header>
    <b>🐾 PetStore</b>
    <nav>
        <a href="index.php">Home</a>
        <a href="cart.php">🛒 Cart</a>
        <a href="user_dashboard.php">👤 Dashboard</a>
        <a href="profile.php">Profile</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<div class="container">

<div class="hero">
    <h1>Welcome, <?= htmlspecialchars($fname) ?> 👋</h1>
    <p>Your personal PetStore dashboard</p>

    <?php if ($fname === 'flag'): ?>
        <p style="font-weight:bold;color:#064e3b;">
            Good job finding the second flag. Only one more to go.
        </p>
    <?php endif; ?>
</div>

<div class="cards">
    <div class="card">
        <h3>🛒 Cart</h3>
        <p>View your selected items</p>
        <a href="cart.php">Open</a>
    </div>

    <div class="card">
        <h3>📦 Orders</h3>
        <p>Order history (soon)</p>
        <a href="#">Coming Soon</a>
    </div>

    <div class="card">
        <h3>👤 Profile</h3>
        <p>Personal information</p>
        <a href="profile.php">Edit</a>
    </div>

    <div class="card">
        <h3>🎁 Gift</h3>
        <p>Discount code</p>
        <b>WELCOME50</b>
    </div>
</div>

</div>
</body>
</html>

