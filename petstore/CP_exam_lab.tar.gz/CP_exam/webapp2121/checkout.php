<?php
session_start();

if (!isset($_SESSION['cart']) || count($_SESSION['cart']['items']) === 0) {
    header("Location: cart.php");
    exit;
}

$total = 0;
foreach ($_SESSION['cart']['items'] as $i) {
    $total += $i['price'];
}

if ($_SESSION['cart']['discount'] > 0) {
    $total *= (1 - $_SESSION['cart']['discount']);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Checkout</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #f0f2f5;
    padding: 40px;
}

.box {
    max-width: 500px;
    margin: auto;
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
}

label {
    display: block;
    margin-top: 15px;
    font-weight: bold;
}

input {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
}

button {
    margin-top: 20px;
    width: 100%;
    background: #2ecc71;
    color: white;
    padding: 12px;
    border: none;
    font-size: 16px;
    border-radius: 6px;
    cursor: pointer;
}

.total {
    text-align: center;
    font-size: 18px;
    margin-top: 10px;
}
</style>
</head>

<body>

<div class="box">
<h2>💳 Checkout</h2>

<form method="post" action="purchase.php">

<label>Card Number (12 digits)</label>
<input type="text" name="card" pattern="\d{12}" required>

<label>Expiration Date</label>
<input type="month" name="exp" required>

<label>CVV (3 digits)</label>
<input type="text" name="cvv" pattern="\d{3}" required>

<label>Email for receipt</label>
<input type="email" name="email" required>

<p class="total"><b>Total:</b> <?= number_format($total, 2) ?> €</p>

<button>Pay Now</button>

</form>
</div>

</body>
</html>

