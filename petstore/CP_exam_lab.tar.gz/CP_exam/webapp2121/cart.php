<?php
session_start();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [
        'items' => [],
        'discount' => 0
    ];
}

$items = $_SESSION['cart']['items'];
$discount = $_SESSION['cart']['discount'];

$total = 0;
foreach ($items as $i) {
    $total += $i['price'];
}

if ($discount > 0) {
    $total = $total * (1 - $discount);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Your Cart</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #f6f7fb;
    padding: 30px;
}

.cart-box {
    max-width: 600px;
    margin: auto;
    background: #fff;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
}

.cart-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.cart-item form {
    margin: 0;
}

button {
    padding: 6px 12px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.remove-btn {
    background: #ff4d4d;
    color: white;
}

.apply-btn {
    background: #4c6ef5;
    color: white;
}

.checkout-btn {
    width: 100%;
    background: #2ecc71;
    color: white;
    padding: 12px;
    font-size: 16px;
    margin-top: 15px;
}

input[type="text"] {
    padding: 8px;
    width: 70%;
}

.total {
    font-size: 18px;
    margin-top: 10px;
}

.back {
    display: block;
    text-align: center;
    margin-top: 15px;
    text-decoration: none;
}
</style>
</head>

<body>

<div class="cart-box">

<h2>🛒 Your Cart</h2>

<?php if (count($items) === 0): ?>
    <i>Cart is empty</i>
<?php else: ?>
    <?php foreach ($items as $index => $i): ?>
        <div class="cart-item">
            <span>
                <?= htmlspecialchars($i['name']) ?> –
                <?= number_format($i['price'], 2) ?> €
            </span>

            <form method="post" action="cart_remove.php">
                <input type="hidden" name="index" value="<?= $index ?>">
                <button class="remove-btn">Remove</button>
            </form>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<hr>

<form method="post" action="cart_coupon.php">
    <input type="text" name="code" placeholder="Discount code">
    <button class="apply-btn">Apply</button>
</form>

<p class="total"><b>Total:</b> <?= number_format($total, 2) ?> €</p>

<?php if (count($items) > 0): ?>
    <a href="checkout.php">
        <button class="checkout-btn">💳 Proceed to Checkout</button>
    </a>
<?php endif; ?>

<a class="back" href="index.php">⬅ Back to shop</a>

</div>

</body>
</html>

