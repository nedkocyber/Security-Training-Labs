<?php
session_start();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [
        'items' => [],
        'discount' => 0
    ];
}

if (isset($_POST['name'], $_POST['price'])) {
    $_SESSION['cart']['items'][] = [
        'name' => $_POST['name'],
        'price' => (float)$_POST['price']
    ];
}

header("Location: cart.php");
exit;
