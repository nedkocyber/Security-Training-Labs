<?php
session_start();

ini_set('display_errors', 1);
error_reporting(E_ALL);

/* =====================
   DB
===================== */
$conn = new mysqli("mysql", "MegaAdmin", "CantGuessTh!sPass", "petstore");
if ($conn->connect_error) {
    die("DB connection failed");
}

/* =====================
   CART INIT
===================== */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [
        'items' => [],
        'discount' => 0
    ];
}

/* =====================
   ADD TO CART
===================== */
if (isset($_POST['add_to_cart'])) {
    $_SESSION['cart']['items'][] = [
        'name'  => $_POST['item'],
        'price' => (float)$_POST['price']
    ];

    header("Location: index.php");
    exit;
}

/* =====================
   LOGOUT
===================== */
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}

/* =====================
   SEARCH & FILTER
===================== */
$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';

$sql = "SELECT name, description, price, rating FROM items WHERE 1";

if ($search !== '') {
    // VULNERABILITY: Add closing quote and comment to break out
    $sql .= " AND (name LIKE '%$search%' OR description LIKE '%$search%')";
}

if ($category !== '') {
    $sql .= " AND name LIKE '%$category%'";
}

$res = $conn->query($sql);
$items = [];

if ($res) {
    while ($row = $res->fetch_assoc()) {
        $items[] = $row;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>PetStore</title>

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #eef2f1;
}
header {
    background: #1f4037;
    color: white;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
nav a, nav span {
    color: white;
    margin-left: 18px;
    text-decoration: none;
    font-weight: bold;
}
nav a:hover {
    text-decoration: underline;
}
.cart {
    position: relative;
    cursor: pointer;
}
.cart-box {
    background: #fff;
    color: #000;
    padding: 10px;
    border-radius: 6px;
    position: absolute;
    right: 0;
    top: 35px;
    width: 260px;
    display: none;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}
.cart:hover .cart-box {
    display: block;
}
.container {
    padding: 20px;
}
.filters, .item {
    background: white;
    padding: 15px;
    border-radius: 6px;
    margin-bottom: 15px;
}
button {
    background: #1f4037;
    color: white;
    border: none;
    padding: 8px 14px;
    cursor: pointer;
    border-radius: 4px;
}
button:hover {
    background: #16332c;
}
select, input {
    padding: 6px;
}
</style>
</head>

<body>

<header>
    <b>🐾 PetStore</b>

    <nav>
        <a href="index.php">Home</a>
        <a href="cart.php">🛒 Cart (<?= count($_SESSION['cart']['items']) ?>)</a>

        <?php if (isset($_SESSION['user'])): ?>
            <a href="user_dashboard.php">👤 Dashboard</a>
            <a href="profile.php">Profile</a>
            <span><?= htmlspecialchars($_SESSION['user']) ?></span>
            <a href="?logout=1">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>

        <span class="cart">🧺
            <div class="cart-box">
                <?php if (empty($_SESSION['cart']['items'])): ?>
                    <i>Cart is empty</i>
                <?php else: ?>
                    <?php foreach ($_SESSION['cart']['items'] as $c): ?>
                        <div>
                            <?= htmlspecialchars($c['name']) ?> – <?= number_format($c['price'], 2) ?> €
                        </div>
                    <?php endforeach; ?>
                    <hr>
                    <a href="cart.php">View cart</a>
                <?php endif; ?>
            </div>
        </span>
    </nav>
</header>

<div class="container">

<h2>Products & Services</h2>

<div class="filters">
<form method="get">
    <input type="text" name="search" placeholder="Search..." value="<?= htmlspecialchars($search) ?>">
    <select name="category">
        <option value="">All</option>
        <option value="Food">Food</option>
        <option value="Toy">Toys</option>
        <option value="Groom">Grooming</option>
        <option value="Service">Services</option>
    </select>
    <button type="submit">Filter</button>
</form>
</div>

<?php foreach ($items as $item): ?>
<div class="item">
    <h3><?= htmlspecialchars($item['name']) ?></h3>
    <p><?= htmlspecialchars($item['description']) ?></p>
    <p><b>Price:</b> <?= number_format($item['price'], 2) ?> €</p>
    <p><?= str_repeat("⭐", (int)$item['rating']) ?></p>

    <?php if (isset($_SESSION['user'])): ?>
        <form method="post">
            <input type="hidden" name="item" value="<?= htmlspecialchars($item['name']) ?>">
            <input type="hidden" name="price" value="<?= $item['price'] ?>">
            <button type="submit" name="add_to_cart">Add to Cart</button>
        </form>
    <?php else: ?>
        <i>Login required to order</i>
    <?php endif; ?>
</div>
<?php endforeach; ?>

</div>
</body>
</html>
