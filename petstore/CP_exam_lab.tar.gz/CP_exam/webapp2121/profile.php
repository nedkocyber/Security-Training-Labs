<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

$conn = new mysqli(
    "mysql",
    "MegaAdmin",
    "CantGuessTh!sPass",
    "petstore"
);

if ($conn->connect_error) {
    die("DB error");
}

$email = $_SESSION['user'];
$msg = "";

if (isset($_POST['update_profile'])) {
    $first = $_POST['first_name'] ?? '';
    $last = $_POST['last_name'] ?? '';
    $new_email = $_POST['email'] ?? '';

    $conn->query("
        UPDATE users SET
            first_name='$first',
            last_name='$last',
            email='$new_email'
        WHERE email='$email'
    ");

    $_SESSION['user'] = $new_email;
    $email = $new_email;
    $msg = "Profile updated";
}

if (isset($_POST['change_password'])) {
    $new = $_POST['new_password'] ?? '';

    if ($new !== '') {
        $conn->query("
            UPDATE users SET password='$new'
            WHERE email='$email'
        ");
        $msg = "Password changed";
    }
}

$res = $conn->query("SELECT * FROM users WHERE email='$email'");
$data = $res->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My Profile</title>
<style>
body {
    font-family: Arial;
    background: #f4f4f4;
    margin: 0;
}
header {
    background: #222;
    color: #fff;
    padding: 15px;
}
header a {
    color: #fff;
    margin-right: 15px;
    text-decoration: none;
}
.container {
    padding: 20px;
}
.box {
    background: #fff;
    padding: 20px;
    margin-bottom: 20px;
    border-radius: 6px;
}
input {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
}
button {
    padding: 10px;
    background: #222;
    color: #fff;
    border: none;
    cursor: pointer;
}
.success {
    color: green;
}
.discount {
    background: #222;
    color: #fff;
    padding: 15px;
    text-align: center;
    font-size: 18px;
}
</style>
</head>
<body>

<header>
    <a href="index.php">Home</a>
    <a href="cart.php">Cart</a>
    <a href="profile.php">My Profile</a>
    <a href="index.php?logout=1">Logout</a>
</header>

<div class="container">

<?php if ($msg): ?>
<p class="success"><?= $msg ?></p>
<?php endif; ?>

<div class="box">
<h2>Personal Information</h2>
<form method="post">
    <input type="text" name="first_name" placeholder="First name" value="<?= $data['first_name'] ?? '' ?>">
    <input type="text" name="last_name" placeholder="Last name" value="<?= $data['last_name'] ?? '' ?>">
    <input type="email" name="email" placeholder="Email" value="<?= $data['email'] ?? '' ?>">
    <input type="text" value="01-01-1999" disabled>
    <button type="submit" name="update_profile">Save</button>
</form>
</div>

<div class="box">
<h2>Change Password</h2>
<form method="post">
    <input type="password" name="new_password" placeholder="New password">
    <button type="submit" name="change_password">Change Password</button>
</form>
</div>

<div class="discount">
DISCOUNT CODE: <b>WELCOME50</b><br>
This is a thanks gift for every new user
</div>

</div>
</body>
</html>

