<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

require_once __DIR__ . "/admin_header.php";

$admin = $_SESSION['admin'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>
<style>
body {
    margin: 0;
    font-family: Arial;
    background: #f4f6f8;
}
header {
    background: #1e1e2f;
    color: white;
    padding: 15px;
}
nav a {
    color: white;
    margin-left: 15px;
    text-decoration: none;
}
.container {
    padding: 20px;
}
.card {
    background: white;
    padding: 20px;
    border-radius: 6px;
    margin-bottom: 20px;
}
.warning {
    color: red;
}
</style>
</head>
<body>

<header>
    <b>🛠 PetStore Admin</b>
</header>

<?php require_once __DIR__ . "/admin_nav.php"; ?>

<div class="container">

<div class="card">
    <h2>Welcome, <?= htmlspecialchars($admin['first_name']) ?></h2>
    <p><b>Username:</b> <?= htmlspecialchars($admin['username']) ?></p>
    <p><b>Email:</b> <?= htmlspecialchars($admin['email']) ?></p>
    <p><b>Password hash:</b></p>
    <code><?= $admin['password'] ?></code>
    <p class="warning">⚠ Sensitive data exposed (intentional for demo)</p>
</div>

<div class="card">
    <h3>📦 Orders Overview (Demo)</h3>
    <ul>
        <li>#1001 – €49.99 – Completed</li>
        <li>#1002 – €19.99 – Pending</li>
        <li>#1003 – €99.99 – Cancelled</li>
    </ul>
</div>

</div>

</body>
</html>

