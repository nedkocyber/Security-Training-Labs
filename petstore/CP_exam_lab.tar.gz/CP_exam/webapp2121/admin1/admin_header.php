<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
?>

<header class="admin-header">
    <div class="logo">🛠 PetStore Admin</div>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="dashboard.php">Admin Info</a>
        <a href="admin_panel.php">Users</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

