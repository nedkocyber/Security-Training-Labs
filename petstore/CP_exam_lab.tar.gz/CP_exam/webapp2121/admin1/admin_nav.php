<nav style="background:#121212; padding:15px;">
    <a href="dashboard.php" style="color:#00ffcc; margin-right:15px;">Dashboard</a>
    <a href="admin_panel.php" style="color:#00ffcc; margin-right:15px;">Manage Users</a>
    <a href="index.php" style="color:#00ffcc; margin-right:15px;">Admin Home</a>
    <a href="logout.php" style="color:#ff6b6b;">Logout</a>
</nav>
<hr>
