<?php
session_start();

ini_set('display_errors', 1);
error_reporting(E_ALL);

/* DB */
$conn = new mysqli("mysql", "MegaAdmin", "CantGuessTh!sPass", "petstore");
if ($conn->connect_error) {
    die("DB error");
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $sql = "
        SELECT *
        FROM admins
        WHERE username = ?
        AND is_admin = true
        AND (
            password = SHA1(?) OR
            password = SHA2(?, 512)
        )
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $password, $password);
    $stmt->execute();

    $res = $stmt->get_result();

    if ($res && $res->num_rows === 1) {
        $_SESSION['admin'] = $res->fetch_assoc();
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid admin credentials";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Login</title>
<style>
body {
    background: #1e1e2f;
    color: white;
    font-family: Arial;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}
.box {
    background: #2a2a40;
    padding: 30px;
    border-radius: 8px;
    width: 340px;
}
input, button {
    width: 100%;
    padding: 10px;
    margin-top: 10px;
}
button {
    background: #ff6b6b;
    border: none;
    color: white;
    cursor: pointer;
}
.error {
    color: #ff6b6b;
    margin-top: 10px;
}
</style>
</head>
<body>

<div class="box">
    <h2>🔐 Admin Login</h2>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post">
        <input name="username" placeholder="Admin username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button>Login</button>
    </form>
</div>

</body>
</html>











































































































































































































































































































/*
Theese are test credentials make sure to remove them when the website is ready!!!
user: testadmin
pass: testpass
*/
