<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require_once __DIR__ . "/admin_header.php";

$conn = new mysqli("mysql", "MegaAdmin", "CantGuessTh!sPass", "petstore");
if ($conn->connect_error) {
    die("DB error");
}

if (isset($_POST['add_user'])) {
    $fn = $_POST['first_name'];
    $ln = $_POST['last_name'];
    $em = $_POST['email'];
    $pw = $_POST['password'];

    $conn->query(
        "INSERT INTO users (first_name,last_name,email,password,is_admin)
         VALUES ('$fn','$ln','$em','$pw',0)"
    );

    header("Location: admin_panel.php?msg=User added");
    exit;
}

if (isset($_POST['update_user'])) {
    $id = $_POST['id'];
    $fn = $_POST['first_name'];
    $ln = $_POST['last_name'];
    $em = $_POST['email'];
    $pw = $_POST['password'];

    $conn->query(
        "UPDATE users SET
         first_name='$fn',
         last_name='$ln',
         email='$em',
         password='$pw'
         WHERE id=$id AND is_admin=0"
    );

    header("Location: admin_panel.php?msg=User updated");
    exit;
}

if (isset($_GET['delete_user'])) {
    $id = $_GET['delete_user'];
    $conn->query("DELETE FROM users WHERE id=$id AND is_admin=0");
    header("Location: admin_panel.php?msg=User deleted");
    exit;
}

$res = $conn->query("SELECT * FROM users WHERE is_admin=0");
$users = [];
while ($row = $res->fetch_assoc()) {
    $users[] = $row;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Panel</title>
<style>
body {
    background:#0b1220;
    color:#e5e7eb;
    font-family:Arial;
    margin:0;
}
.container {
    padding:25px;
}
h1,h2 {
    color:#38bdf8;
}
.box {
    background:#020617;
    padding:20px;
    border-radius:10px;
    margin-bottom:30px;
    box-shadow:0 0 15px rgba(0,0,0,.4);
}
table {
    width:100%;
    border-collapse:collapse;
}
th,td {
    padding:10px;
    border-bottom:1px solid #1e293b;
}
th {
    background:#1e293b;
}
input {
    padding:6px;
    background:#020617;
    color:#e5e7eb;
    border:1px solid #334155;
}
button {
    background:#2563eb;
    color:white;
    border:none;
    padding:6px 12px;
    border-radius:4px;
    cursor:pointer;
}
button:hover {
    background:#1d4ed8;
}
a {
    color:#f87171;
    text-decoration:none;
}
.alert {
    background:#7c2d12;
    padding:10px;
    border-radius:6px;
    margin-bottom:20px;
}
</style>
</head>
<body>

<?php require_once __DIR__ . "/admin_nav.php"; ?>

<div class="container">

<h1>🛠 Admin Panel</h1>

<?php if (isset($_GET['msg'])): ?>
<div class="alert"><?= $_GET['msg'] ?></div>
<?php endif; ?>

<div class="box">
<h2>Add User</h2>
<form method="post">
    <input name="first_name" placeholder="First name">
    <input name="last_name" placeholder="Last name">
    <input name="email" placeholder="Email">
    <input name="password" placeholder="Password">
    <button name="add_user">Add</button>
</form>
</div>

<div class="box">
<h2>Users</h2>
<table>
<tr>
    <th>ID</th>
    <th>First</th>
    <th>Last</th>
    <th>Email</th>
    <th>Password</th>
    <th>Actions</th>
</tr>

<?php foreach ($users as $u): ?>
<tr>
<form method="post">
    <td><?= $u['id'] ?></td>
    <td><input name="first_name" value="<?= $u['first_name'] ?>"></td>
    <td><input name="last_name" value="<?= $u['last_name'] ?>"></td>
    <td><input name="email" value="<?= $u['email'] ?>"></td>
    <td><input name="password" value="<?= $u['password'] ?>"></td>
    <td>
        <input type="hidden" name="id" value="<?= $u['id'] ?>">
        <button name="update_user">Save</button>
        <a href="?delete_user=<?= $u['id'] ?>">❌</a>
    </td>
</form>
</tr>
<?php endforeach; ?>

</table>
</div>

</div>

</body>
</html>

