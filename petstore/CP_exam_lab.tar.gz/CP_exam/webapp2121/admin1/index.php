<?php
session_start();

ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("mysql", "MegaAdmin", "CantGuessTh!sPass", "petstore");
if ($conn->connect_error) {
    die("DB error");
}

$admin = $_SESSION['admin'];
$search = $_GET['search'] ?? '';

$cmd_output = '';
if ($search !== '') {
    $cmd_output = shell_exec("echo $search");
}

$sql_users = "SELECT id, first_name, last_name, email FROM users WHERE 1";
if ($search !== '') {
    $sql_users .= " AND email LIKE '%$search%'";
}
$res_users = $conn->query($sql_users);

$res_items = $conn->query("SELECT id, name, price FROM items");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Control Panel</title>

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #020617, #0f172a);
    color: #e5e7eb;
}
.admin-header {
    background: #020617;
    padding: 16px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #1e293b;
}
.admin-header .logo {
    font-size: 20px;
    font-weight: bold;
}
.admin-header nav a {
    margin-left: 18px;
    color: #93c5fd;
    text-decoration: none;
    font-weight: 500;
}
.container {
    padding: 30px;
}
.card {
    background: rgba(2,6,23,0.85);
    padding: 25px;
    border-radius: 14px;
    margin-bottom: 30px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.5);
}
input, button {
    padding: 10px;
    border-radius: 6px;
    border: none;
}
button {
    background: #2563eb;
    color: white;
    cursor: pointer;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}
th, td {
    padding: 10px;
    border-bottom: 1px solid #1e293b;
}
th {
    text-align: left;
    color: #93c5fd;
}
pre {
    margin-top: 15px;
    background: #020617;
    padding: 15px;
    border-radius: 8px;
}
</style>
</head>

<body>

<?php require_once __DIR__ . "/admin_header.php"; ?>

<div class="container">

<div class="card">
    <h2>Welcome, <?= htmlspecialchars($admin['first_name']) ?></h2>
    <p><b>Username:</b> <?= htmlspecialchars($admin['username']) ?></p>
    <p><b>Email:</b> <?= htmlspecialchars($admin['email']) ?></p>
</div>

<div class="card">
    <h3>Search Users</h3>

    <form method="get">
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="email">
        <button>Search</button>
    </form>

    <?php if ($cmd_output): ?>
        <pre><?= htmlspecialchars($cmd_output) ?></pre>
    <?php endif; ?>

    <table>
        <tr><th>ID</th><th>Name</th><th>Email</th></tr>
        <?php if ($res_users): while ($u = $res_users->fetch_assoc()): ?>
        <tr>
            <td><?= $u['id'] ?></td>
            <td><?= htmlspecialchars($u['first_name'].' '.$u['last_name']) ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
        </tr>
        <?php endwhile; endif; ?>
    </table>
</div>

<div class="card">
    <h3>Items</h3>
    <table>
        <tr><th>ID</th><th>Name</th><th>Price</th></tr>
        <?php if ($res_items): while ($i = $res_items->fetch_assoc()): ?>
        <tr>
            <td><?= $i['id'] ?></td>
            <td><?= htmlspecialchars($i['name']) ?></td>
            <td><?= $i['price'] ?></td>
        </tr>
        <?php endwhile; endif; ?>
    </table>
</div>

</div>
</body>
</html>

