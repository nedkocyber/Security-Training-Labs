<?php
session_start();

if (!isset($_SESSION['cart']) || count($_SESSION['cart']['items']) === 0) {
    header("Location: index.php");
    exit;
}

$email = $_POST['email'] ?? 'unknown@example.com';

/* Clear cart after purchase */
$_SESSION['cart'] = [
    'items' => [],
    'discount' => 0
];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Payment Successful</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #eef6f0;
    padding: 40px;
}

.box {
    max-width: 500px;
    margin: auto;
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    text-align: center;
}

.success {
    font-size: 22px;
    color: #2ecc71;
}

small {
    color: #666;
}

a {
    display: inline-block;
    margin-top: 20px;
    text-decoration: none;
    background: #3498db;
    color: white;
    padding: 10px 20px;
    border-radius: 6px;
}
</style>
</head>

<body>

<div class="box">
<div class="success">✅ Payment Successful</div>

<p>Thank you for your purchase!</p>

<p>
🧾 Receipt sent to:<br>
<b><?= htmlspecialchars($email) ?></b>
</p>

<small>Enjoy.</small>

<br><br>
<a href="index.php">⬅ Back to shop</a>
</div>

</body>
</html>

