<?php
session_start();

if (isset($_POST['index'], $_SESSION['cart']['items'])) {
    $i = (int)$_POST['index'];

    if (isset($_SESSION['cart']['items'][$i])) {
        unset($_SESSION['cart']['items'][$i]);
        $_SESSION['cart']['items'] = array_values($_SESSION['cart']['items']);
    }
}

header("Location: cart.php");
exit;
