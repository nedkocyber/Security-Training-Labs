<?php
session_start();

if (!isset($_SESSION['cart'])) {
    header("Location: cart.php");
    exit;
}

$code = $_POST['code'] ?? '';

if ($code !== 'WELCOME50') {
    header("Location: cart.php?msg=invalid");
    exit;
}

/*
 RACE CONDITION
*/
if ($_SESSION['cart']['discount'] == 0) {
    usleep(300000); // race window
    $_SESSION['cart']['discount'] += 0.5;
}

header("Location: cart.php");
exit;

