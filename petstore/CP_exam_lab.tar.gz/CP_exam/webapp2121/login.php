<?php
session_start();

ini_set('display_errors', 1);
error_reporting(E_ALL);

$conn = new mysqli(
    "mysql",
    "MegaAdmin",
    "CantGuessTh!sPass",
    "petstore"
);

if ($conn->connect_error) {
    die("DB error");
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $sql = "SELECT email, first_name FROM users WHERE email='$email' AND password='$password'";
    $res = $conn->query($sql);

    if ($res && $res->num_rows === 1) {
        $row = $res->fetch_assoc();
        $_SESSION['user'] = $row['email'];
        $_SESSION['fname'] = $row['first_name'];
        header("Location: user_dashboard.php");
        exit;
    } else {
        $error = "Invalid email or password";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>PetStore | Login</title>

<style>
body {
    background: #f4f7f6;
    font-family: Arial, sans-serif;
}
.box {
    width: 350px;
    margin: 100px auto;
    background: white;
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0 0 15px rgba(0,0,0,0.1);
}
h2 {
    text-align: center;
    color: #2c7;
}
input {
    width: 100%;
    padding: 10px;
    margin-top: 10px;
}
button {
    width: 100%;
    margin-top: 15px;
    padding: 10px;
    background: #2c7;
    border: none;
    color: white;
    font-size: 16px;
    cursor: pointer;
}
.error {
    color: red;
    text-align: center;
}
a {
    display: block;
    text-align: center;
    margin-top: 15px;
}
</style>
</head>

<body>

<div class="box">
    <h2>🐾 PetStore Login</h2>

    <form method="post">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button>Login</button>
    </form>

    <p class="error"><?= htmlspecialchars($error) ?></p>

    <a href="index.php">← Back to Home</a>
</div>

</body>
</html>

