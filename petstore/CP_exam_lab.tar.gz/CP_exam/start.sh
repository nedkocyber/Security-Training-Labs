#!/bin/bash

echo "[*] Starting CP Exam Lab..."

# Проверка дали docker работи
if ! systemctl is-active --quiet docker; then
    echo "[!] Docker is not running. Starting Docker..."
    systemctl start docker
fi

# Стартиране на контейнерите
docker-compose up -d --build

if [ $? -eq 0 ]; then
    echo "[+] Lab started successfully!"
    echo "[+] Services:"
    echo "    - Web     : http://localhost"
    echo "    - FTP     : ftp://localhost:80"
    echo "    - SSH     : localhost:22"
    echo "    - MySQL   : localhost:3306"
else
    echo "[!] Failed to start lab."
fi
