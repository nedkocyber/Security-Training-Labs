#!/bin/bash

echo "[*] Stopping CP Exam Lab..."

docker-compose down

if [ $? -eq 0 ]; then
    echo "[+] Lab stopped successfully."
    echo "[+] No data was deleted."
else
    echo "[!] Failed to stop lab."
fi
