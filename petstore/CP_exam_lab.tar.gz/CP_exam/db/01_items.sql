USE petstore;

DROP TABLE IF EXISTS items;

CREATE TABLE items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150),
    description TEXT,
    price DECIMAL(10,2),
    rating INT
);

INSERT INTO items (name, description, price, rating) VALUES
-- Food
('Dog Food Premium Beef 10kg', 'Premium beef-based dog food providing complete nutrition for adult dogs.', 39.99, 5),
('Dog Food Chicken 5kg', 'Chicken-flavored dog food ideal for daily feeding.', 24.50, 4),
('Cat Food Salmon 3kg', 'High-protein salmon cat food for healthy fur and digestion.', 22.99, 5),
('Cat Food Tuna 1kg', 'Light tuna-based food suitable for indoor cats.', 11.99, 4),
('Bird Seed Mix Deluxe', 'Deluxe seed mix designed for birds of all sizes.', 9.50, 3),
('Hamster Food Mix', 'Balanced food mix supporting hamster health.', 6.99, 4),
('Rabbit Food Pellets', 'Nutritious pellets specially formulated for rabbits.', 7.80, 4),
('Fish Flakes Tropical', 'Tropical fish flakes for vibrant colors and energy.', 4.99, 3),
('Fish Food Goldfish', 'Daily nutrition food for goldfish.', 3.50, 3),
('Dog Treats Bacon', 'Tasty bacon-flavored treats for training and rewards.', 5.99, 5),

-- Toys
('Dog Toy Rubber Bone', 'Durable rubber bone for strong chewers.', 8.99, 5),
('Dog Toy Rope', 'Rope toy designed for tugging and chewing.', 6.50, 4),
('Cat Toy Laser Pointer', 'Interactive laser toy keeping cats active.', 12.99, 5),
('Cat Toy Feather Stick', 'Feather stick toy stimulating hunting instincts.', 4.50, 4),
('Bird Mirror Toy', 'Mirror toy designed to entertain pet birds.', 3.99, 3),
('Hamster Running Ball', 'Exercise ball allowing hamsters to move freely.', 9.99, 4),
('Rabbit Chew Toy', 'Chew toy promoting dental health for rabbits.', 2.99, 3),
('Interactive Dog Puzzle', 'Puzzle toy that challenges and entertains dogs.', 19.99, 5),
('Catnip Toy Mouse', 'Catnip-filled mouse toy to excite cats.', 3.49, 4),
('Squeaky Dog Toy', 'Squeaky toy providing hours of fun for dogs.', 7.25, 5),

-- Beds & Houses
('Dog Bed Large', 'Large comfortable bed suitable for big dogs.', 59.99, 5),
('Dog Bed Medium', 'Medium-sized dog bed with soft padding.', 44.99, 4),
('Cat Bed Soft', 'Soft and warm bed for cats.', 34.50, 4),
('Cat House Indoor', 'Indoor cat house providing a safe resting space.', 49.99, 5),
('Bird Cage Small', 'Compact cage suitable for small birds.', 69.99, 4),
('Bird Cage Large', 'Spacious cage designed for multiple birds.', 119.99, 5),
('Hamster Cage Basic', 'Basic cage setup for hamsters.', 39.99, 3),
('Rabbit Hutch Outdoor', 'Outdoor hutch protecting rabbits from weather.', 149.99, 5),
('Dog House Plastic', 'Plastic dog house resistant to rain and wind.', 89.99, 4),
('Dog House Wooden', 'Premium wooden dog house for outdoor use.', 179.99, 5),

-- Clothing
('Dog Jacket Winter', 'Warm winter jacket for dogs in cold climates.', 29.99, 5),
('Dog Raincoat', 'Waterproof raincoat keeping dogs dry.', 24.99, 4),
('Dog Shoes Set', 'Protective shoes for dog paws.', 19.50, 3),
('Cat Sweater Cute', 'Cute sweater providing warmth for cats.', 17.99, 4),
('Pet Costume Pirate', 'Fun pirate costume for pets.', 21.99, 5),
('Pet Costume Santa', 'Festive Santa costume for pets.', 23.50, 5),
('Dog Collar Leather', 'Durable leather collar with classic design.', 14.99, 4),
('Dog Collar LED', 'LED collar improving visibility at night.', 18.99, 5),
('Cat Collar Bell', 'Lightweight collar with bell for cats.', 6.99, 4),
('Pet Bandana', 'Stylish bandana accessory for pets.', 4.99, 3),

-- Accessories
('Dog Leash Nylon', 'Strong nylon leash suitable for daily walks.', 12.99, 4),
('Dog Leash Retractable', 'Retractable leash offering flexible control.', 29.99, 5),
('Food Bowl Stainless Steel', 'Durable stainless steel food bowl.', 9.99, 4),
('Water Dispenser', 'Automatic water dispenser for pets.', 19.99, 4),
('Pet Travel Carrier', 'Carrier designed for safe pet transportation.', 49.99, 5),
('Car Seat Cover for Pets', 'Protective seat cover for traveling with pets.', 34.99, 4),
('Pet Backpack Carrier', 'Backpack carrier for small pets.', 59.99, 5),
('Automatic Feeder', 'Automatic feeder ensuring scheduled meals.', 79.99, 5),
('Pet Camera WiFi', 'WiFi-enabled camera to monitor pets remotely.', 99.99, 5),
('Pet Nail Clippers', 'Easy-to-use nail clippers for pets.', 7.99, 4),

-- Grooming
('Pet Shampoo Sensitive Skin', 'Gentle shampoo for pets with sensitive skin.', 8.99, 4),
('Pet Shampoo Flea Control', 'Shampoo helping control fleas and parasites.', 11.99, 4),
('Pet Brush Soft', 'Soft brush for gentle grooming.', 6.50, 3),
('Pet Deshedding Tool', 'Tool reducing excessive pet shedding.', 19.99, 5),
('Pet Toothbrush Kit', 'Complete dental care kit for pets.', 9.99, 4),
('Pet Hair Dryer', 'Low-noise dryer designed for pets.', 49.99, 4),
('Pet Wipes Pack', 'Cleaning wipes for quick pet hygiene.', 5.99, 3),
('Pet Perfume', 'Light pet perfume with pleasant scent.', 12.50, 3),
('Pet Ear Cleaner', 'Cleaner maintaining ear hygiene for pets.', 7.75, 4),
('Pet Paw Balm', 'Protective balm for pet paws.', 6.99, 4),

-- Services
('Pet Grooming Basic Service', 'Basic grooming service including wash and trim.', 29.99, 5),
('Pet Grooming Full Package', 'Full grooming package with premium care.', 59.99, 5),
('Dog Training Session', 'Professional dog training session.', 45.00, 5),
('Puppy Training Course', 'Complete training course for puppies.', 199.99, 5),
('Pet Sitting Per Day', 'Daily pet sitting service.', 25.00, 4),
('Dog Walking 30 Minutes', '30-minute dog walking service.', 15.00, 4),
('Veterinary Checkup', 'General veterinary health check.', 49.99, 5),
('Vaccination Service', 'Standard pet vaccination service.', 39.99, 5),
('Pet Microchipping', 'Microchipping service for pet identification.', 29.99, 5),
('Emergency Vet Visit', 'Emergency veterinary assistance.', 99.99, 5);

