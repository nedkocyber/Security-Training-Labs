USE petstore;

DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    password VARCHAR(100),
    is_admin BOOLEAN DEFAULT false
);

INSERT INTO users (first_name, last_name, email, password, is_admin) VALUES
('John', 'Miller', 'john.miller@petstore.com', 'Jm!l2023', false),
('Sarah', 'Johnson', 'sarah.johnson@petstore.com', 'SaR#8891', false),
('Michael', 'Brown', 'michael.brown@petstore.com', 'Mb_7722', false),
('Emily', 'Davis', 'emily.davis@petstore.com', 'Em!ly55', false),
('Daniel', 'Wilson', 'daniel.wilson@petstore.com', 'DW@2022', false),
('Olivia', 'Taylor', 'olivia.taylor@petstore.com', 'Ol!v14', false),
('James', 'Anderson', 'james.anderson@petstore.com', 'JAx#93', false),
('Sophia', 'Thomas', 'sophia.thomas@petstore.com', 'SoP@777', false),
('David', 'Moore', 'david.moore@petstore.com', 'Dm_456!', false),
('Emma', 'Martin', 'emma.martin@petstore.com', 'EmM@09', false),

('Lucas', 'White', 'lucas.white@petstore.com', 'LW#3321', false),
('Mia', 'Clark', 'mia.clark@petstore.com', 'Mi@888', false),
('Ethan', 'Lewis', 'ethan.lewis@petstore.com', 'EL!902', false),
('Ava', 'Walker', 'ava.walker@petstore.com', 'Av@444', false),
('Noah', 'Hall', 'noah.hall@petstore.com', 'Nh#77Q', false),
('Isabella', 'Allen', 'isabella.allen@petstore.com', 'Isa!33', false),
('Benjamin', 'Young', 'ben.young@petstore.com', 'By#2020', false),
('Charlotte', 'King', 'charlotte.king@petstore.com', 'Ch@K9', false),
('Henry', 'Wright', 'henry.wright@petstore.com', 'Hw_998', false),
('Amelia', 'Lopez', 'amelia.lopez@petstore.com', 'AmL#55', false),

('Alexander', 'Scott', 'alex.scott@petstore.com', 'ASc!12', false),
('Harper', 'Green', 'harper.green@petstore.com', 'HG@777', false),
('Matthew', 'Baker', 'matthew.baker@petstore.com', 'Mbk#99', false),
('Evelyn', 'Gonzalez', 'evelyn.gonzalez@petstore.com', 'EvG!66', false),
('Sebastian', 'Nelson', 'sebastian.nelson@petstore.com', 'Sn@2023', false),
('Lily', 'Carter', 'lily.carter@petstore.com', 'LC!888', false),
('Jack', 'Mitchell', 'jack.mitchell@petstore.com', 'JM@456', false),
('Grace', 'Perez', 'grace.perez@petstore.com', 'GP#77', false),
('Owen', 'Roberts', 'owen.roberts@petstore.com', 'OR!99', false),

-- Fake admin user (confusion)
('admin', 'admin', 'admin@petstore.com', 'admin', false),
-- Flag user
('flag', 'flag', 'flag@flag.flag', '327a6c4304ad5938eaf0efb6cc3e53dc', false);
