USE petstore;

DROP TABLE IF EXISTS admins;

CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    username VARCHAR(50),
    password VARCHAR(128),
    is_admin BOOLEAN DEFAULT true
);

INSERT INTO admins
(first_name, last_name, email, username, password, is_admin)
VALUES
(
    'Ethan',
    'Stone',
    'penetraiontester@petstore.com',
    'PenTester',
    SHA1('rootadmin123'),
    true
),
(
    'Liam',
    'Carter',
    'webadmin@petstore.com',
    'WebAdmin',
    SHA2('superadmin123', 512),
    true
),
(
    'BigBad',
    'BitingDog',
    'bigbadbitingdog@petstore.com',
    'BigDogBoss',
    SHA1('adminadmin1234'),
    true
);
