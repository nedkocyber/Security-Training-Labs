-- ПРЕМАХВА ВСИЧКИ СТАРИ ВАРИАНТИ
DROP USER IF EXISTS 'MegaAdmin'@'localhost';
DROP USER IF EXISTS 'MegaAdmin'@'%';

-- СЪЗДАВА НАНОВО
CREATE USER 'MegaAdmin'@'%'
IDENTIFIED WITH mysql_native_password
BY 'CantGuessTh!sPass';

GRANT ALL PRIVILEGES ON petstore.* TO 'MegaAdmin'@'%';
FLUSH PRIVILEGES;

