#!/bin/bash

set -e

echo "[*] Stopping containers & wiping volumes/images..."
docker compose down -v --rmi all --remove-orphans

echo "[*] Resetting web files..."

# Ако имаш генерирани/качени файлове
rm -f webapp2121/*.log
rm -f webapp2121/*.cache
rm -f webapp2121/*.tmp

# Сесии (ако ги пазиш локално)
rm -rf webapp2121/sessions
mkdir -p webapp2121/sessions
chmod 777 webapp2121/sessions

echo "[*] Rebuilding and starting lab..."
docker compose up -d --build

echo "[+] Lab is ready."

