#!/bin/bash
cd /home/kali/Bank_CTF
docker compose up -d
echo "[+] Bank_CTF started."
