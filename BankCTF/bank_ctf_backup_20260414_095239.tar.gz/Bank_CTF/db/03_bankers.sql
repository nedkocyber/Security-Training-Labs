USE bank;

INSERT IGNORE INTO bankers (username, password, email, full_name) VALUES
('banker_john', SHA2('johnsecret', 512), 'john@bank.com', 'John Banker'),
('banker_jane', SHA2('janesecure', 512), 'jane@bank.com', 'Jane Banker');
