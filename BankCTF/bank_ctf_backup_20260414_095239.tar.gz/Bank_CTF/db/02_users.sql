USE bank;

INSERT IGNORE INTO users (id, username, password, email, fname, lname, iban) VALUES
(1, 'alice', MD5('password!'), 'alice@bank.com', 'Alice', 'Smith', 'BG80BNBG10000000000001'),
(2, 'bob', MD5('123456@'), 'bob@bank.com', 'Bob', 'Johnson', 'BG80BNBG10000000000002'),
(3, 'charlie', MD5('qwerty#'), 'charlie@bank.com', 'Charlie', 'Brown', 'BG80BNBG10000000000003'),
(4, 'david', MD5('abc123$'), 'david@bank.com', 'David', 'Wilson', 'BG80BNBG10000000000004'),
(5, 'eve', MD5('password1%'), 'eve@bank.com', 'Eve', 'Martinez', 'BG80BNBG10000000000005'),
(6, 'frank', MD5('admin^'), 'frank@bank.com', 'Frank', 'Anderson', 'BG80BNBG10000000000006'),
(7, 'grace', MD5('welcome&'), 'grace@bank.com', 'Grace', 'Thomas', 'BG80BNBG10000000000007'),
(8, 'hank', MD5('login*'), 'hank@bank.com', 'Hank', 'Taylor', 'BG80BNBG10000000000008'),
(9, 'ivy', MD5('sunshine('), 'ivy@bank.com', 'Ivy', 'Moore', 'BG80BNBG10000000000009'),
(10, 'jack', MD5('master)'), 'jack@bank.com', 'Jack', 'Jackson', 'BG80BNBG10000000000010'),
(11, 'kate', MD5('hello_'), 'kate@bank.com', 'Kate', 'White', 'BG80BNBG10000000000011'),
(12, 'leo', MD5('freedom+'), 'leo@bank.com', 'Leo', 'Harris', 'BG80BNBG10000000000012'),
(13, 'mia', MD5('computer='), 'mia@bank.com', 'Mia', 'Martin', 'BG80BNBG10000000000013'),
(14, 'nick', MD5('shadow-'), 'nick@bank.com', 'Nick', 'Thompson', 'BG80BNBG10000000000014'),
(15, 'olivia', MD5('secret`'), 'olivia@bank.com', 'Olivia', 'Garcia', 'BG80BNBG10000000000015'),
(16, 'paul', MD5('dragon~'), 'paul@bank.com', 'Paul', 'Martinez', 'BG80BNBG10000000000016'),
(17, 'quinn', MD5('starwars!'), 'quinn@bank.com', 'Quinn', 'Robinson', 'BG80BNBG10000000000017'),
(18, 'rose', MD5('baseball@'), 'rose@bank.com', 'Rose', 'Clark', 'BG80BNBG10000000000018'),
(19, 'sam', MD5('football#'), 'sam@bank.com', 'Sam', 'Rodriguez', 'BG80BNBG10000000000019'),
(20, 'tina', MD5('iloveyou$'), 'tina@bank.com', 'Tina', 'Lewis', 'BG80BNBG10000000000020'),
(21, 'ulysses', MD5('trustno1%'), 'ulysses@bank.com', 'Ulysses', 'Lee', 'BG80BNBG10000000000021'),
(22, 'vicky', MD5('monkey^'), 'vicky@bank.com', 'Vicky', 'Walker', 'BG80BNBG10000000000022'),
(23, 'will', MD5('letmein&'), 'will@bank.com', 'Will', 'Hall', 'BG80BNBG10000000000023'),
(24, 'xena', MD5('whatever*'), 'xena@bank.com', 'Xena', 'Allen', 'BG80BNBG10000000000024'),
(25, 'yara', MD5('pass123('), 'yara@bank.com', 'Yara', 'Young', 'BG80BNBG10000000000025'),
(26, 'zane', MD5('access)'), 'zane@bank.com', 'Zane', 'King', 'BG80BNBG10000000000026'),
(27, 'adam', MD5('shadow_'), 'adam@bank.com', 'Adam', 'Wright', 'BG80BNBG10000000000027'),
(28, 'bella', MD5('master+'), 'bella@bank.com', 'Bella', 'Scott', 'BG80BNBG10000000000028'),
(29, 'chris', MD5('hello='), 'chris@bank.com', 'Chris', 'Green', 'BG80BNBG10000000000029'),
(30, 'diana', MD5('freedom-'), 'diana@bank.com', 'Diana', 'Baker', 'BG80BNBG10000000000030');

-- Създаване на сметки (accounts) за всеки потребител (начален баланс 0)
INSERT IGNORE INTO accounts (user_id, balance)
SELECT id, 0 FROM users;

-- Създаване на начални салда за валутите (всички валути с баланс 0)
INSERT IGNORE INTO user_balances (user_id, currency_id, balance)
SELECT u.id, c.id, 0
FROM users u, currencies c;
