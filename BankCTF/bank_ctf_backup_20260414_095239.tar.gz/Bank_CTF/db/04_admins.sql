USE bank;

INSERT IGNORE INTO admins (username, password, email, full_name) VALUES
('admin', SHA2('adminadmin1233333333333333', 512), 'admin@bank.com', 'Super Admin'),
('root', SHA2('rootpasssssss!@#', 512), 'root@bank.com', 'Root Admin'),
('djjj', SHA2('adminadmin123', 512), 'djjj@bank.com', 'DJ JJ');
