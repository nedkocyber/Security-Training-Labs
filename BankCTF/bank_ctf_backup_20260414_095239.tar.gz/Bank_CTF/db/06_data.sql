-- Вмъкване на валути
INSERT IGNORE INTO currencies (code, name, type, exchange_rate_to_usd) VALUES
('USD', 'US Dollar', 'fiat', 1.00000000),
('EUR', 'Euro', 'fiat', 1.08000000),
('GBP', 'British Pound', 'fiat', 1.25000000),
('BTC', 'Bitcoin', 'crypto', 60000.00000000),
('ETH', 'Ethereum', 'crypto', 3000.00000000);

-- Създаване на обменни курсове (спрямо USD)
INSERT IGNORE INTO exchange_rates (from_currency_id, to_currency_id, rate)
SELECT c1.id, c2.id, c2.exchange_rate_to_usd / c1.exchange_rate_to_usd
FROM currencies c1, currencies c2
WHERE c1.code != c2.code;

-- Салда: всеки потребител получава USD сметка с начален баланс (ако няма)
INSERT IGNORE INTO user_balances (user_id, currency_id, balance)
SELECT u.id, c.id, 1000.00
FROM users u, currencies c
WHERE c.code = 'USD'
AND NOT EXISTS (SELECT 1 FROM user_balances ub WHERE ub.user_id = u.id AND ub.currency_id = c.id);
