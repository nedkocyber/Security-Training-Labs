-- ============================================
-- Bank_CTF – Само конфигурация (схема + валути + права)
-- ============================================

CREATE DATABASE IF NOT EXISTS bank;
USE bank;

-- ============================================
-- 1. Основни таблици (без примерни данни)
-- ============================================

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    fname VARCHAR(50),
    lname VARCHAR(50),
    iban VARCHAR(34) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bankers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    full_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    full_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS accounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    balance DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    frozen BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- 2. Валути и разширени функционалности (конфигурация)
-- ============================================

CREATE TABLE IF NOT EXISTS currencies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL UNIQUE,
    name VARCHAR(50) NOT NULL,
    type ENUM('fiat', 'crypto') NOT NULL,
    exchange_rate_to_usd DECIMAL(20,8) NOT NULL
);

CREATE TABLE IF NOT EXISTS user_balances (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    currency_id INT NOT NULL,
    balance DECIMAL(20,8) NOT NULL DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (currency_id) REFERENCES currencies(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_currency (user_id, currency_id)
);

CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('transfer', 'exchange', 'deposit', 'crypto_buy', 'crypto_sell') NOT NULL,
    from_currency_id INT NULL,
    to_currency_id INT NULL,
    amount DECIMAL(20,8) NOT NULL,
    rate DECIMAL(20,8) NULL,
    description TEXT,
    status ENUM('pending', 'completed', 'rejected') DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (from_currency_id) REFERENCES currencies(id),
    FOREIGN KEY (to_currency_id) REFERENCES currencies(id)
);

CREATE TABLE IF NOT EXISTS exchange_rates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    from_currency_id INT NOT NULL,
    to_currency_id INT NOT NULL,
    rate DECIMAL(20,8) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (from_currency_id) REFERENCES currencies(id),
    FOREIGN KEY (to_currency_id) REFERENCES currencies(id),
    UNIQUE KEY unique_pair (from_currency_id, to_currency_id)
);

-- ============================================
-- 3. Фиксирани данни (валути и обменни курсове)
-- ============================================

INSERT IGNORE INTO currencies (code, name, type, exchange_rate_to_usd) VALUES
('USD', 'US Dollar', 'fiat', 1.00000000),
('EUR', 'Euro', 'fiat', 1.08000000),
('GBP', 'British Pound', 'fiat', 1.25000000),
('BTC', 'Bitcoin', 'crypto', 60000.00000000),
('ETH', 'Ethereum', 'crypto', 3000.00000000);

INSERT IGNORE INTO exchange_rates (from_currency_id, to_currency_id, rate)
SELECT c1.id, c2.id, c2.exchange_rate_to_usd / c1.exchange_rate_to_usd
FROM currencies c1, currencies c2
WHERE c1.id != c2.id;

-- ============================================
-- 4. Създаване на потребители за приложенията и права
-- ============================================

-- Потребител за web приложението (обикновени клиенти)
CREATE USER IF NOT EXISTS 'webuser'@'%' IDENTIFIED BY 'webpass';
GRANT SELECT, INSERT, UPDATE ON bank.users TO 'webuser'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON bank.accounts TO 'webuser'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE ON bank.user_balances TO 'webuser'@'%';
GRANT SELECT, INSERT ON bank.transactions TO 'webuser'@'%';
GRANT SELECT ON bank.currencies TO 'webuser'@'%';
GRANT SELECT ON bank.exchange_rates TO 'webuser'@'%';
GRANT SELECT ON bank.bankers TO 'webuser'@'%';
GRANT INSERT ON bank.bankers TO 'webuser'@'%';
GRANT SELECT ON bank.admins TO 'webuser'@'%';

-- Потребител за banker приложението
CREATE USER IF NOT EXISTS 'bankeruser'@'%' IDENTIFIED BY 'bankerpass';
GRANT SELECT, UPDATE ON bank.users TO 'bankeruser'@'%';
GRANT SELECT, UPDATE ON bank.accounts TO 'bankeruser'@'%';
GRANT SELECT, INSERT, UPDATE ON bank.user_balances TO 'bankeruser'@'%';
GRANT SELECT, UPDATE ON bank.transactions TO 'bankeruser'@'%';
GRANT SELECT ON bank.* TO 'bankeruser'@'%';

-- Потребител за admin приложението (пълен достъп)
CREATE USER IF NOT EXISTS 'adminuser'@'%' IDENTIFIED BY 'adminpass';
GRANT ALL PRIVILEGES ON bank.* TO 'adminuser'@'%';

-- Общ потребител за четене (ако е необходимо)
CREATE USER IF NOT EXISTS 'bankuser'@'%' IDENTIFIED BY 'bankpass';
GRANT SELECT ON bank.* TO 'bankuser'@'%';

-- Потребителят, който се създава от docker-compose (MYSQL_USER) – даваме му допълнителни права
GRANT ALL PRIVILEGES ON bank.* TO 'bankuser'@'%' WITH GRANT OPTION;

-- ============================================
-- 5. Потребител за phpMyAdmin (ръчен вход)
-- ============================================
CREATE USER IF NOT EXISTS 'admin'@'%' IDENTIFIED BY 'phpmyadminpassword1';
GRANT ALL PRIVILEGES ON bank.* TO 'admin'@'%' WITH GRANT OPTION;

FLUSH PRIVILEGES;
