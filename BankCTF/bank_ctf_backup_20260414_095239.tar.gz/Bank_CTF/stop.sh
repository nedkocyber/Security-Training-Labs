#!/bin/bash
cd /home/kali/Bank_CTF
docker compose down --rmi all
echo "[+] Bank_CTF stopped and all associated images removed."
