<?php
session_start();
$is_logged_in = isset($_SESSION['admin_id']) && $_SESSION['role'] === 'admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MegaBank Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: radial-gradient(circle at 10% 20%, #0a2a1a, #051a0a);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        .dollar-rain {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
        }
        .dollar-rain i {
            position: absolute;
            color: rgba(46, 204, 113, 0.2);
            font-size: 2rem;
            animation: fall linear infinite;
        }
        @keyframes fall {
            0% { transform: translateY(-100px) rotate(0deg); opacity: 0; }
            10% { opacity: 0.8; }
            90% { opacity: 0.8; }
            100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
        }
        .glass-card {
            background: rgba(10, 30, 20, 0.75);
            backdrop-filter: blur(12px);
            border-radius: 2rem;
            padding: 2rem;
            width: 100%;
            max-width: 500px;
            border: 1px solid #2ecc71;
            box-shadow: 0 20px 40px rgba(0,0,0,0.5), 0 0 20px rgba(46,204,113,0.3);
            z-index: 1;
            text-align: center;
            transition: transform 0.3s;
        }
        .glass-card:hover {
            transform: translateY(-5px);
        }
        h1 {
            font-size: 2.5rem;
            color: #2ecc71;
            margin-bottom: 1rem;
            text-shadow: 0 0 5px rgba(46,204,113,0.5);
        }
        .subtitle {
            color: #ccddee;
            margin-bottom: 2rem;
            font-size: 1rem;
        }
        .btn {
            background: #2ecc71;
            color: #0a1a0a;
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 2rem;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: 0.3s;
            margin: 0.5rem;
        }
        .btn:hover {
            background: #27ae60;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(46,204,113,0.4);
        }
        .stats {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin: 2rem 0;
        }
        .stat {
            text-align: center;
        }
        .stat-number {
            font-size: 1.8rem;
            font-weight: bold;
            color: #ffd966;
        }
        .stat-label {
            font-size: 0.8rem;
            color: #88aa99;
        }
        .footer {
            margin-top: 1.5rem;
            font-size: 0.7rem;
            color: #6688aa;
        }
    </style>
</head>
<body>
<div class="dollar-rain" id="dollarRain"></div>
<div class="glass-card">
    <h1>💰 MegaBank</h1>
    <div class="subtitle">Admin Control Center</div>
    <?php if ($is_logged_in): ?>
        <div class="stats">
            <div class="stat">
                <div class="stat-number">🔐</div>
                <div class="stat-label">Logged in as<br><?= htmlspecialchars($_SESSION['username']) ?></div>
            </div>
            <div class="stat">
                <div class="stat-number">⚙️</div>
                <div class="stat-label">Full Access</div>
            </div>
        </div>
        <a href="dashboard.php" class="btn">Enter Dashboard</a>
        <a href="logout.php" class="btn" style="background: #e74c3c;">Logout</a>
    <?php else: ?>
        <div class="stats">
            <div class="stat">
                <div class="stat-number">🔒</div>
                <div class="stat-label">Secure Area</div>
            </div>
            <div class="stat">
                <div class="stat-number">👑</div>
                <div class="stat-label">Admins Only</div>
            </div>
        </div>
        <a href="login.php" class="btn">Login to Admin Panel</a>
    <?php endif; ?>
    <div class="footer">
        <i class="fas fa-shield-alt"></i> Protected by MegaBank Security
    </div>
</div>

<script>
    const rainContainer = document.getElementById('dollarRain');
    const symbols = ['$', '💰', '💵', '💸', '🪙'];
    for (let i = 0; i < 60; i++) {
        const el = document.createElement('i');
        el.classList.add('fas');
        el.textContent = symbols[Math.floor(Math.random() * symbols.length)];
        el.style.left = Math.random() * 100 + '%';
        el.style.animationDuration = 3 + Math.random() * 5 + 's';
        el.style.animationDelay = Math.random() * 10 + 's';
        el.style.fontSize = 1 + Math.random() * 2 + 'rem';
        rainContainer.appendChild(el);
    }
</script>
</body>
</html>
