<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$pageTitle = $pageTitle ?? 'BankCTF';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> - BankCTF</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f4f4f4; }
        .container { max-width: 800px; margin: auto; background: white; padding: 20px; border-radius: 5px; }
        nav { background: #333; color: white; padding: 10px; }
        nav a { color: white; margin-right: 15px; text-decoration: none; }
        .error { color: red; }
        .success { color: green; }
    </style>
</head>
<body>
<nav>
    <a href="index.php">Home</a>
    <?php if (isset($_SESSION['role'])): ?>
        <?php if ($_SESSION['role'] === 'user'): ?>
            <a href="dashboard.php">Dashboard</a>
        <?php elseif ($_SESSION['role'] === 'banker'): ?>
            <a href="dashboard.php">Banker Panel</a>
        <?php elseif ($_SESSION['role'] === 'admin'): ?>
            <a href="dashboard.php">Admin Panel</a>
        <?php endif; ?>
        <a href="logout.php">Logout</a>
    <?php else: ?>
        <a href="login.php">Login</a>
    <?php endif; ?>
</nav>
<div class="container">
