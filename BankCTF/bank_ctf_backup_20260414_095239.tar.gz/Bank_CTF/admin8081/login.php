<?php
session_start();
if (isset($_SESSION['admin_id']) && $_SESSION['role'] === 'admin') {
    header('Location: dashboard.php');
    exit;
}

require_once 'db_connect.php';

$error = '';
$username_entered = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_entered = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT id, username, password FROM admins WHERE username = ?");
    $stmt->execute([$username_entered]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        $error = "Invalid username or password.";
    } else {
        if (hash('sha512', $password) === $admin['password']) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['username'] = $admin['username'];
            $_SESSION['role'] = 'admin';
            header('Location: dashboard.php');
            exit;
        } else {
            $error = "Invalid username or password.";
        }
    }
}

$pageTitle = "Admin Login";
require_once 'includes/header.php';
?>

<style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
        background: linear-gradient(135deg, #0a2a1a 0%, #051a0a 100%);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
    }
    .dollar-rain {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 0;
    }
    .dollar-rain i {
        position: absolute;
        color: rgba(46, 204, 113, 0.15);
        font-size: 2rem;
        animation: fall linear infinite;
    }
    @keyframes fall {
        0% { transform: translateY(-100px) rotate(0deg); opacity: 0; }
        10% { opacity: 1; }
        90% { opacity: 1; }
        100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
    }
    .glass-card {
        background: rgba(10, 30, 20, 0.7);
        backdrop-filter: blur(12px);
        border-radius: 2rem;
        padding: 2rem;
        width: 100%;
        max-width: 400px;
        border: 1px solid #2ecc71;
        box-shadow: 0 20px 40px rgba(0,0,0,0.5), 0 0 20px rgba(46,204,113,0.3);
        z-index: 1;
        transition: transform 0.3s;
    }
    .glass-card:hover { transform: translateY(-5px); }
    h2 {
        text-align: center;
        color: #2ecc71;
        font-size: 2rem;
        margin-bottom: 1rem;
        letter-spacing: 2px;
        text-shadow: 0 0 5px rgba(46,204,113,0.5);
    }
    .money-icon {
        text-align: center;
        font-size: 3rem;
        margin-bottom: 0.5rem;
        color: #ffd966;
    }
    .input-group {
        margin-bottom: 1.2rem;
    }
    label {
        display: block;
        color: #ccddee;
        margin-bottom: 0.5rem;
        font-weight: 500;
    }
    label i {
        color: #2ecc71;
        margin-right: 0.5rem;
    }
    input {
        width: 100%;
        padding: 0.8rem;
        background: #1a2a22;
        border: 1px solid #2ecc71;
        border-radius: 12px;
        color: #fff;
        font-size: 1rem;
        transition: 0.3s;
    }
    input:focus {
        outline: none;
        border-color: #ffd966;
        box-shadow: 0 0 10px rgba(255,217,102,0.5);
        background: #1e3a2a;
    }
    button {
        width: 100%;
        padding: 0.8rem;
        background: #2ecc71;
        color: #0a1a0a;
        border: none;
        border-radius: 12px;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
        margin-top: 0.5rem;
    }
    button:hover {
        background: #27ae60;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(46,204,113,0.4);
    }
    .error {
        background: rgba(231,76,60,0.2);
        border-left: 4px solid #e74c3c;
        padding: 0.8rem;
        margin-bottom: 1rem;
        border-radius: 8px;
        text-align: center;
        color: #ff8888;
    }
    .footer {
        text-align: center;
        margin-top: 1.5rem;
        font-size: 0.75rem;
        color: #88aa99;
    }
    .footer i {
        color: #2ecc71;
    }
</style>

<div class="dollar-rain" id="dollarRain"></div>
<div class="glass-card">
    <div class="money-icon">💰 $ 💰</div>
    <h2>Admin Treasury</h2>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post">
        <div class="input-group">
            <label><i class="fas fa-user-tie"></i> Username</label>
            <input type="text" name="username" value="<?= htmlspecialchars($username_entered) ?>" required autofocus>
        </div>
        <div class="input-group">
            <label><i class="fas fa-dollar-sign"></i> Password</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit"><i class="fas fa-coins"></i> Login</button>
    </form>
    <div class="footer">
        <i class="fas fa-shield-alt"></i> Secure Money Portal | MegaBank
    </div>
</div>

<script>
    const rainContainer = document.getElementById('dollarRain');
    const symbols = ['$', '💰', '💵', '💸', '🪙'];
    for (let i = 0; i < 60; i++) {
        const el = document.createElement('i');
        el.classList.add('fas');
        el.textContent = symbols[Math.floor(Math.random() * symbols.length)];
        el.style.left = Math.random() * 100 + '%';
        el.style.animationDuration = 3 + Math.random() * 5 + 's';
        el.style.animationDelay = Math.random() * 10 + 's';
        el.style.fontSize = 1 + Math.random() * 2 + 'rem';
        rainContainer.appendChild(el);
    }
</script>

<?php require_once 'includes/footer.php'; ?>
