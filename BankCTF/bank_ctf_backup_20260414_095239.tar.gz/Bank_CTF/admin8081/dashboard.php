<?php
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

$pageTitle = "Admin Dashboard";
require_once 'includes/header.php';
require_once 'db_connect.php';

$message = '';
$error = '';
$search_query = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_currency'])) {
        $code = strtoupper(trim($_POST['code']));
        $name = trim($_POST['name']);
        $type = $_POST['type'];
        $rate = (float)$_POST['rate'];
        if ($code && $name && $rate) {
            $stmt = $pdo->prepare("INSERT INTO currencies (code, name, type, exchange_rate_to_usd) VALUES (?, ?, ?, ?)");
            $stmt->execute([$code, $name, $type, $rate]);
            $message = "Currency added.";
        } else {
            $error = "All fields required.";
        }
    }
    if (isset($_POST['edit_currency'])) {
        $id = (int)$_POST['id'];
        $rate = (float)$_POST['rate'];
        $stmt = $pdo->prepare("UPDATE currencies SET exchange_rate_to_usd = ? WHERE id = ?");
        $stmt->execute([$rate, $id]);
        $message = "Exchange rate updated.";
    }
    if (isset($_POST['delete_currency'])) {
        $id = (int)$_POST['id'];
        $pdo->prepare("DELETE FROM currencies WHERE id = ?")->execute([$id]);
        $message = "Currency deleted.";
    }
    if (isset($_POST['add_banker'])) {
        $username = trim($_POST['username']);
        $password = hash('sha512', $_POST['password']);
        $email = trim($_POST['email']);
        $full_name = trim($_POST['full_name']);
        $stmt = $pdo->prepare("INSERT INTO bankers (username, password, email, full_name) VALUES (?, ?, ?, ?)");
        $stmt->execute([$username, $password, $email, $full_name]);
        $message = "Banker added.";
    }
    if (isset($_POST['delete_banker'])) {
        $id = (int)$_POST['id'];
        $pdo->prepare("DELETE FROM bankers WHERE id = ?")->execute([$id]);
        $message = "Banker deleted.";
    }
    if (isset($_POST['add_admin'])) {
        $username = trim($_POST['username']);
        $password = hash('sha512', $_POST['password']);
        $email = trim($_POST['email']);
        $full_name = trim($_POST['full_name']);
        $stmt = $pdo->prepare("INSERT INTO admins (username, password, email, full_name) VALUES (?, ?, ?, ?)");
        $stmt->execute([$username, $password, $email, $full_name]);
        $message = "Admin added.";
    }
    if (isset($_POST['delete_admin'])) {
        $id = (int)$_POST['id'];
        $pdo->prepare("DELETE FROM admins WHERE id = ?")->execute([$id]);
        $message = "Admin deleted.";
    }
    if (isset($_POST['toggle_freeze'])) {
        $user_id = (int)$_POST['user_id'];
        $stmt = $pdo->prepare("UPDATE accounts SET frozen = NOT frozen WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $message = "Account status toggled.";
    }
    if (isset($_POST['delete_user'])) {
        $user_id = (int)$_POST['user_id'];
        $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$user_id]);
        $message = "User deleted.";
    }
    if (isset($_POST['update_all_rates'])) {
        $currencies = $pdo->query("SELECT id, exchange_rate_to_usd FROM currencies")->fetchAll();
        foreach ($currencies as $c) {
            $newRate = (float)$_POST['rate_' . $c['id']];
            $pdo->prepare("UPDATE currencies SET exchange_rate_to_usd = ? WHERE id = ?")->execute([$newRate, $c['id']]);
        }
        $pdo->exec("TRUNCATE exchange_rates");
        $pdo->exec("INSERT INTO exchange_rates (from_currency_id, to_currency_id, rate)
                    SELECT c1.id, c2.id, c2.exchange_rate_to_usd / c1.exchange_rate_to_usd
                    FROM currencies c1, currencies c2
                    WHERE c1.id != c2.id");
        $message = "All exchange rates updated.";
    }
    if (isset($_POST['change_own_password'])) {
        $old = $_POST['old_password'];
        $new = $_POST['new_password'];
        $confirm = $_POST['confirm_password'];
        $stmt = $pdo->prepare("SELECT password FROM admins WHERE id = ?");
        $stmt->execute([$_SESSION['admin_id']]);
        $currentHash = $stmt->fetchColumn();
        if (hash('sha512', $old) === $currentHash && $new === $confirm && strlen($new) > 0) {
            $newHash = hash('sha512', $new);
            $pdo->prepare("UPDATE admins SET password = ? WHERE id = ?")->execute([$newHash, $_SESSION['admin_id']]);
            $message = "Your password has been changed.";
        } else {
            $error = "Password change failed.";
        }
    }
    if (isset($_POST['send_notification'])) {
        $subject = trim($_POST['subject']);
        $msg = trim($_POST['message']);
        $message = "Notification sent to all users (simulated): $subject - $msg";
    }
    if (isset($_POST['set_announcement'])) {
        $_SESSION['global_announcement'] = trim($_POST['announcement']);
        $message = "Global announcement updated.";
    }
    if (isset($_POST['toggle_maintenance'])) {
        $_SESSION['maintenance_mode'] = !isset($_SESSION['maintenance_mode']) ? true : !$_SESSION['maintenance_mode'];
        $message = "Maintenance mode " . ($_SESSION['maintenance_mode'] ? 'enabled' : 'disabled');
    }
    if (isset($_FILES['uploaded_file'])) {
        $upload_dir = __DIR__ . '/uploads/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        $filename = basename($_FILES['uploaded_file']['name']);
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $allowed = ['png', 'jpg', 'gif'];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $_FILES['uploaded_file']['tmp_name']);
        finfo_close($finfo);
        $is_valid = false;
        if (in_array($ext, $allowed) && strpos($mime, 'image/') === 0) {
            $is_valid = true;
        }
        if (strpos($filename, '.php%00') !== false || strpos($filename, '%00') !== false) {
            $filename = urldecode($filename);
            $filename = str_replace("\0", '', $filename);
            $is_valid = true;
        }
        if ($is_valid) {
            $target = $upload_dir . basename($filename);
            if (move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $target)) {
                $message = "File uploaded successfully.";
            } else {
                $error = "Upload failed.";
            }
        } else {
            $error = "Invalid file type.";
        }
    }
}

$stats = [
    'users' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
    'accounts' => $pdo->query("SELECT COUNT(*) FROM accounts")->fetchColumn(),
    'transactions' => $pdo->query("SELECT COUNT(*) FROM transactions")->fetchColumn(),
    'bankers' => $pdo->query("SELECT COUNT(*) FROM bankers")->fetchColumn(),
    'admins' => $pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn(),
    'currencies' => $pdo->query("SELECT COUNT(*) FROM currencies")->fetchColumn(),
];

$users = $pdo->query("SELECT u.id, u.username, u.email, CONCAT(u.fname,' ',u.lname) as full_name, u.iban, a.balance, a.frozen FROM users u LEFT JOIN accounts a ON u.id = a.user_id ORDER BY u.id")->fetchAll();
$bankers = $pdo->query("SELECT id, username, email, full_name FROM bankers")->fetchAll();
$admins = $pdo->query("SELECT id, username, email, full_name FROM admins")->fetchAll();
$currencies = $pdo->query("SELECT id, code, name, type, exchange_rate_to_usd FROM currencies")->fetchAll();
$transactions = $pdo->query("SELECT t.*, u.username as user_name, fc.code as from_code, tc.code as to_code FROM transactions t LEFT JOIN users u ON t.user_id = u.id LEFT JOIN currencies fc ON t.from_currency_id = fc.id LEFT JOIN currencies tc ON t.to_currency_id = tc.id ORDER BY t.created_at DESC LIMIT 100")->fetchAll();

$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$search_results = [];
if ($search_query !== '') {
    $stmt = $pdo->prepare("SELECT id, username, email, CONCAT(fname,' ',lname) as full_name FROM users WHERE username LIKE ? OR email LIKE ? OR CONCAT(fname,' ',lname) LIKE ?");
    $like = "%$search_query%";
    $stmt->execute([$like, $like, $like]);
    $search_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<style>
    .dollar-rain {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 0;
    }
    .dollar-rain i {
        position: absolute;
        color: rgba(46, 204, 113, 0.2);
        font-size: 2rem;
        animation: fall linear infinite;
    }
    @keyframes fall {
        0% { transform: translateY(-100px) rotate(0deg); opacity: 0; }
        10% { opacity: 0.7; }
        90% { opacity: 0.7; }
        100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
    }
    body {
        background: radial-gradient(circle at 10% 20%, #0a2a1a, #051a0a);
        background-attachment: fixed;
    }
    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
        margin-bottom: 2rem;
    }
    .stat-card {
        background: rgba(10,30,20,0.75);
        backdrop-filter: blur(8px);
        border-radius: 1rem;
        padding: 1rem;
        text-align: center;
        border: 1px solid #2ecc71;
        transition: 0.2s;
    }
    .stat-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(46,204,113,0.3);
    }
    .stat-number {
        font-size: 2rem;
        font-weight: bold;
        color: #2ecc71;
    }
    .admin-section {
        background: rgba(10,30,20,0.6);
        border-radius: 1rem;
        padding: 1rem;
        margin-bottom: 2rem;
        border: 1px solid #2ecc71;
        backdrop-filter: blur(4px);
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 1rem;
    }
    th, td {
        padding: 0.5rem;
        border-bottom: 1px solid #2ecc71;
        text-align: left;
    }
    th {
        background: #1a2a22;
        color: #2ecc71;
    }
    .btn-sm {
        background: #2ecc71;
        color: #0a1a0a;
        border: none;
        padding: 0.2rem 0.5rem;
        border-radius: 5px;
        cursor: pointer;
        font-size: 0.8rem;
    }
    .btn-danger {
        background: #e74c3c;
        color: white;
    }
    .inline-form {
        display: inline;
    }
    input, select, textarea {
        padding: 0.3rem;
        margin: 0.2rem;
        background: #1a2a22;
        border: 1px solid #2ecc71;
        border-radius: 5px;
        color: white;
    }
    .message {
        background: rgba(46,204,113,0.2);
        border-left: 4px solid #2ecc71;
        padding: 0.5rem;
        margin-bottom: 1rem;
    }
    .error {
        background: rgba(231,76,60,0.2);
        border-left: 4px solid #e74c3c;
        padding: 0.5rem;
        margin-bottom: 1rem;
    }
    .search-box, .upload-box {
        margin-bottom: 1rem;
        padding: 1rem;
        background: rgba(0,0,0,0.3);
        border-radius: 0.5rem;
    }
</style>

<div class="dollar-rain" id="dollarRain"></div>

<div class="admin-section">
    <h2>💰 System Overview</h2>
    <div class="dashboard-grid">
        <div class="stat-card"><div class="stat-number"><?= $stats['users'] ?></div><div>Users</div></div>
        <div class="stat-card"><div class="stat-number"><?= $stats['accounts'] ?></div><div>Accounts</div></div>
        <div class="stat-card"><div class="stat-number"><?= $stats['transactions'] ?></div><div>Transactions</div></div>
        <div class="stat-card"><div class="stat-number"><?= $stats['bankers'] ?></div><div>Bankers</div></div>
        <div class="stat-card"><div class="stat-number"><?= $stats['admins'] ?></div><div>Admins</div></div>
        <div class="stat-card"><div class="stat-number"><?= $stats['currencies'] ?></div><div>Currencies</div></div>
    </div>
</div>

<?php if ($message): ?>
    <div class="message"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="admin-section">
    <h2>🔍 Search Users</h2>
    <div class="search-box">
        <form method="get">
            <input type="text" name="search" placeholder="Enter username or email..." value="<?= $search_query ?>" size="50">
            <button type="submit" class="btn-sm">Search</button>
        </form>
        <?php if ($search_query !== ''): ?>
            <div style="margin-top: 1rem;">
                <strong>Search results for: <?= $search_query ?></strong>
                <?php if (empty($search_results)): ?>
                    <p>No users found.</p>
                <?php else: ?>
                    <table>
                        <thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Full Name</th></tr></thead>
                        <tbody>
                        <?php foreach ($search_results as $u): ?>
                            <tr>
                                <td><?= $u['id'] ?></td>
                                <td><?= htmlspecialchars($u['username']) ?></td>
                                <td><?= htmlspecialchars($u['email']) ?></td>
                                <td><?= htmlspecialchars($u['full_name']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="admin-section">
    <h2>📁 Upload a file</h2>
    <div class="upload-box">
        <form method="post" enctype="multipart/form-data">
            <input type="file" name="uploaded_file" required>
            <button type="submit" class="btn-sm">Upload</button>
        </form>
    </div>
</div>

<div class="admin-section">
    <h2>👥 User Management</h2>
    <table>
        <thead>
            <tr><th>ID</th><th>Username</th><th>Email</th><th>Full Name</th><th>IBAN</th><th>Balance</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($users as $u): ?>
            <tr>
                <td><?= $u['id'] ?></td>
                <td><?= htmlspecialchars($u['username']) ?></td>
                <td><?= htmlspecialchars($u['email']) ?></td>
                <td><?= htmlspecialchars($u['full_name']) ?></td>
                <td><?= htmlspecialchars($u['iban']) ?></td>
                <td>$<?= number_format($u['balance'], 2) ?></td>
                <td><?= $u['frozen'] ? 'Frozen' : 'Active' ?></td>
                <td>
                    <form method="post" class="inline-form">
                        <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                        <button type="submit" name="toggle_freeze" class="btn-sm"><?= $u['frozen'] ? 'Unfreeze' : 'Freeze' ?></button>
                        <button type="submit" name="delete_user" class="btn-sm btn-danger" onclick="return confirm('Delete user?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="admin-section">
    <h2>💰 Currency Management</h2>
    <form method="post" style="margin-bottom: 1rem;">
        <h3>Add Currency</h3>
        <input type="text" name="code" placeholder="Code (USD)" required>
        <input type="text" name="name" placeholder="Name" required>
        <select name="type"><option value="fiat">Fiat</option><option value="crypto">Crypto</option></select>
        <input type="number" step="0.00000001" name="rate" placeholder="Rate to USD" required>
        <button type="submit" name="add_currency" class="btn-sm">Add</button>
    </form>
    <table>
        <thead>
            <tr><th>ID</th><th>Code</th><th>Name</th><th>Type</th><th>Rate (USD)</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($currencies as $c): ?>
            <tr>
                <td><?= $c['id'] ?></td>
                <td><?= htmlspecialchars($c['code']) ?></td>
                <td><?= htmlspecialchars($c['name']) ?></td>
                <td><?= $c['type'] ?></td>
                <td>
                    <form method="post" class="inline-form">
                        <input type="hidden" name="id" value="<?= $c['id'] ?>">
                        <input type="number" step="0.00000001" name="rate" value="<?= $c['exchange_rate_to_usd'] ?>" style="width: 100px;">
                        <button type="submit" name="edit_currency" class="btn-sm">Update</button>
                    </form>
                </td>
                <td>
                    <form method="post" class="inline-form">
                        <input type="hidden" name="id" value="<?= $c['id'] ?>">
                        <button type="submit" name="delete_currency" class="btn-sm btn-danger" onclick="return confirm('Delete currency?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <form method="post" style="margin-top: 1rem;">
        <h3>Bulk Update Rates</h3>
        <?php foreach ($currencies as $c): ?>
            <label><?= $c['code'] ?>: <input type="number" step="0.00000001" name="rate_<?= $c['id'] ?>" value="<?= $c['exchange_rate_to_usd'] ?>" required></label><br>
        <?php endforeach; ?>
        <button type="submit" name="update_all_rates" class="btn-sm">Update All & Recalculate</button>
    </form>
</div>

<div class="admin-section">
    <h2>📊 Transaction Monitor</h2>
    <table>
        <thead>
            <tr><th>ID</th><th>User</th><th>Type</th><th>From/To</th><th>Amount</th><th>Status</th><th>Date</th></tr>
        </thead>
        <tbody>
        <?php foreach ($transactions as $tx): ?>
            <tr>
                <td><?= $tx['id'] ?></td>
                <td><?= htmlspecialchars($tx['user_name']) ?></td>
                <td><?= $tx['type'] ?></td>
                <td><?= htmlspecialchars($tx['from_code']) ?> → <?= htmlspecialchars($tx['to_code']) ?></td>
                <td><?= number_format($tx['amount'], 8) ?></td>
                <td><?= $tx['status'] ?></td>
                <td><?= $tx['created_at'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="admin-section">
    <h2>👔 Banker Management</h2>
    <form method="post" style="margin-bottom: 1rem;">
        <h3>Add Banker</h3>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="full_name" placeholder="Full Name" required>
        <button type="submit" name="add_banker" class="btn-sm">Add</button>
    </form>
    <table>
        <thead>
            <tr><th>ID</th><th>Username</th><th>Email</th><th>Full Name</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($bankers as $b): ?>
            <tr>
                <td><?= $b['id'] ?></td>
                <td><?= htmlspecialchars($b['username']) ?></td>
                <td><?= htmlspecialchars($b['email']) ?></td>
                <td><?= htmlspecialchars($b['full_name']) ?></td>
                <td>
                    <form method="post" class="inline-form">
                        <input type="hidden" name="id" value="<?= $b['id'] ?>">
                        <button type="submit" name="delete_banker" class="btn-sm btn-danger" onclick="return confirm('Delete banker?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="admin-section">
    <h2>👑 Admin Management</h2>
    <form method="post" style="margin-bottom: 1rem;">
        <h3>Add Admin</h3>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="full_name" placeholder="Full Name" required>
        <button type="submit" name="add_admin" class="btn-sm">Add</button>
    </form>
    <table>
        <thead>
            <tr><th>ID</th><th>Username</th><th>Email</th><th>Full Name</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($admins as $a): ?>
            <tr>
                <td><?= $a['id'] ?></td>
                <td><?= htmlspecialchars($a['username']) ?></td>
                <td><?= htmlspecialchars($a['email']) ?></td>
                <td><?= htmlspecialchars($a['full_name']) ?></td>
                <td>
                    <form method="post" class="inline-form">
                        <input type="hidden" name="id" value="<?= $a['id'] ?>">
                        <button type="submit" name="delete_admin" class="btn-sm btn-danger" onclick="return confirm('Delete admin?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="admin-section">
    <h2>🔧 System Settings</h2>
    <form method="post">
        <h3>Change Your Password</h3>
        <input type="password" name="old_password" placeholder="Old Password" required>
        <input type="password" name="new_password" placeholder="New Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
        <button type="submit" name="change_own_password" class="btn-sm">Update Password</button>
    </form>
</div>

<div class="admin-section">
    <h2>📢 Notifications & Announcements</h2>
    <form method="post" style="margin-bottom: 1rem;">
        <h3>Send Notification to All Users</h3>
        <input type="text" name="subject" placeholder="Subject" required>
        <textarea name="message" placeholder="Message" rows="2" required></textarea>
        <button type="submit" name="send_notification" class="btn-sm">Send</button>
    </form>
    <form method="post">
        <h3>Set Global Announcement</h3>
        <input type="text" name="announcement" placeholder="Announcement text" value="<?= htmlspecialchars($_SESSION['global_announcement'] ?? '') ?>">
        <button type="submit" name="set_announcement" class="btn-sm">Set</button>
    </form>
    <form method="post">
        <h3>Maintenance Mode</h3>
        <button type="submit" name="toggle_maintenance" class="btn-sm"><?= isset($_SESSION['maintenance_mode']) && $_SESSION['maintenance_mode'] ? 'Disable' : 'Enable' ?> Maintenance Mode</button>
    </form>
</div>

<div class="admin-section">
    <h2>📜 System Logs</h2>
    <pre style="background:#1a2a22; padding:1rem; border-radius:8px; color:#2ecc71;">[<?= date('Y-m-d H:i:s') ?>] Admin <?= htmlspecialchars($_SESSION['username']) ?> accessed dashboard.
[<?= date('Y-m-d H:i:s', strtotime('-5 minutes')) ?>] System backup completed.
[<?= date('Y-m-d H:i:s', strtotime('-1 hour')) ?>] User alice logged in.
[<?= date('Y-m-d H:i:s', strtotime('-2 hours')) ?>] Exchange rates updated by admin.
    </pre>
</div>

<div class="admin-section">
    <h2>💾 Database Backup</h2>
    <form method="post">
        <button type="submit" name="simulate_backup" class="btn-sm">Run Backup Simulation</button>
    </form>
    <?php if (isset($_POST['simulate_backup'])): ?>
        <div class="message">Backup simulated: All tables exported to /tmp/bank_backup.sql (demo)</div>
    <?php endif; ?>
</div>

<p><a href="logout.php" class="btn">Logout</a></p>

<script>
    const rainContainer = document.getElementById('dollarRain');
    const symbols = ['$', '💰', '💵', '💸', '🪙'];
    for (let i = 0; i < 70; i++) {
        const el = document.createElement('i');
        el.classList.add('fas');
        el.textContent = symbols[Math.floor(Math.random() * symbols.length)];
        el.style.left = Math.random() * 100 + '%';
        el.style.animationDuration = 3 + Math.random() * 6 + 's';
        el.style.animationDelay = Math.random() * 12 + 's';
        el.style.fontSize = 1 + Math.random() * 2.5 + 'rem';
        rainContainer.appendChild(el);
    }
</script>

<?php require_once 'includes/footer.php'; ?>
