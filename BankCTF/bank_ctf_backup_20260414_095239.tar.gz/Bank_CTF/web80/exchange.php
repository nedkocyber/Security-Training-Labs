<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: login.php');
    exit;
}
$pageTitle = "Currency Exchange";
require_once 'includes/header.php';
require_once 'db_connect.php';

$error = '';
$success = '';
$user_id = $_SESSION['user_id'];

// Вземаме всички валути
$currencies = $pdo->query("SELECT id, code, type FROM currencies ORDER BY type, code")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $from_currency = (int)$_POST['from_currency'];
    $to_currency = (int)$_POST['to_currency'];
    $amount = (float)$_POST['amount'];
    $direction = $_POST['direction']; // 'buy' or 'sell' (за крипто)
    
    // Проверка дали валутите са различни
    if ($from_currency == $to_currency) {
        $error = "Cannot exchange same currency.";
    } else {
        // Взимаме курса
        $stmt = $pdo->prepare("SELECT rate FROM exchange_rates WHERE from_currency_id = ? AND to_currency_id = ?");
        $stmt->execute([$from_currency, $to_currency]);
        $rate = $stmt->fetchColumn();
        if ($rate === false) {
            $error = "Exchange rate not available.";
        } else {
            // Изчисляваме сумата след обмен
            $result_amount = $amount * $rate;
            
            // Проверка на салдото (ако продаваме)
            $stmt = $pdo->prepare("SELECT balance FROM user_balances WHERE user_id = ? AND currency_id = ?");
            $stmt->execute([$user_id, $from_currency]);
            $balance = $stmt->fetchColumn();
            if ($balance < $amount) {
                $error = "Insufficient funds in source currency.";
            } else {
                // Транзакция
                $pdo->beginTransaction();
                try {
                    // Намаляваме от изходната валута
                    $stmt = $pdo->prepare("UPDATE user_balances SET balance = balance - ? WHERE user_id = ? AND currency_id = ?");
                    $stmt->execute([$amount, $user_id, $from_currency]);
                    // Увеличаваме целевата валута
                    $stmt = $pdo->prepare("INSERT INTO user_balances (user_id, currency_id, balance) VALUES (?, ?, ?)
                                            ON DUPLICATE KEY UPDATE balance = balance + VALUES(balance)");
                    $stmt->execute([$user_id, $to_currency, $result_amount]);
                    // Записваме транзакция
                    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, type, from_currency_id, to_currency_id, amount, rate) 
                                            VALUES (?, 'exchange', ?, ?, ?, ?)");
                    $stmt->execute([$user_id, $from_currency, $to_currency, $amount, $rate]);
                    $pdo->commit();
                    $success = "Exchanged $amount to " . number_format($result_amount, 8) . " (rate: $rate)";
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $error = "Exchange failed: " . $e->getMessage();
                }
            }
        }
    }
}
?>
<h2>Currency Exchange</h2>
<?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<form method="post">
    <div class="form-group">
        <label>From Currency</label>
        <select name="from_currency" id="from_currency" required>
            <?php foreach ($currencies as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['code']) ?> (<?= $c['type'] ?>)</option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <label>To Currency</label>
        <select name="to_currency" id="to_currency" required>
            <?php foreach ($currencies as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['code']) ?> (<?= $c['type'] ?>)</option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Amount</label>
        <input type="number" step="0.00000001" name="amount" required>
    </div>
    <button type="submit" class="btn">Exchange</button>
</form>
<script>
    // Ограничаване да не може да се избере една и съща валута
    const fromSelect = document.getElementById('from_currency');
    const toSelect = document.getElementById('to_currency');
    fromSelect.addEventListener('change', function() {
        if (fromSelect.value === toSelect.value) {
            toSelect.value = '';
        }
    });
    toSelect.addEventListener('change', function() {
        if (toSelect.value === fromSelect.value) {
            fromSelect.value = '';
        }
    });
</script>
<?php require_once 'includes/footer.php'; ?>
