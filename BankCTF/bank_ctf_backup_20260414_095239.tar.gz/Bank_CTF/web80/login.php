<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$username_entered = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'db_connect.php';
    $username_entered = trim($_POST['username'] ?? '');
    $password = md5($_POST['password'] ?? '');

    $stmt = $pdo->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->execute([$username_entered]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $error = "Username and password are wrong";
    } else {
        if ($user['password'] === $password) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = 'user';
            header('Location: dashboard.php');
            exit;
        } else {
            $error = "Wrong password for user " . htmlspecialchars($username_entered);
        }
    }
}

$pageTitle = "Login";
require_once 'includes/header.php';
?>

<div class="form-container" style="max-width: 400px; margin: 2rem auto;">
    <h2><i class="fas fa-key"></i> Login to Your Account</h2>
    <?php if ($error): ?>
        <div class="error" style="background: rgba(231, 76, 60, 0.2); border-left: 4px solid #e74c3c; padding: 0.8rem; margin-bottom: 1rem;">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>
    <form method="post">
        <div class="form-group">
            <label><i class="fas fa-user"></i> Username</label>
            <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($username_entered) ?>" required autofocus>
        </div>
        <div class="form-group">
            <label><i class="fas fa-lock"></i> Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn">Login <i class="fas fa-arrow-right"></i></button>
    </form>
    <p style="margin-top: 1rem;">Don't have an account? <a href="register.php">Register here</a></p>
</div>

<?php require_once 'includes/footer.php'; ?>
