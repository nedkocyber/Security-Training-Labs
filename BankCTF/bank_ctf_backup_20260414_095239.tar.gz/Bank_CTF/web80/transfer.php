<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: login.php');
    exit;
}

$source_user_id = isset($_GET['id']) ? (int)$_GET['id'] : $_SESSION['user_id'];

require_once 'db_connect.php';

$error = '';
$success = false;

$stmt = $pdo->prepare("SELECT frozen FROM accounts WHERE user_id = ?");
$stmt->execute([$source_user_id]);
$frozen = $stmt->fetchColumn();
if ($frozen) {
    $error = "Your account is frozen. You cannot make transfers.";
}

$currencies = $pdo->query("SELECT id, code FROM currencies WHERE type='fiat'")->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT username, fname, lname FROM users WHERE id = ?");
$stmt->execute([$source_user_id]);
$source_user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$source_user) {
    die("Invalid source user.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$frozen) {
    $recipient_fname = trim($_POST['fname'] ?? '');
    $recipient_lname = trim($_POST['lname'] ?? '');
    $recipient_iban = trim($_POST['iban'] ?? '');
    $amount = (float)$_POST['amount'];
    $currency_id = (int)$_POST['currency'];

    $stmt = $pdo->prepare("SELECT id, fname, lname FROM users WHERE iban = ?");
    $stmt->execute([$recipient_iban]);
    $iban_user = $stmt->fetch(PDO::FETCH_ASSOC);

    $name_match = false;
    $user_exists = false;

    if ($iban_user) {
        $user_exists = true;
        if (strcasecmp($iban_user['fname'], $recipient_fname) === 0 && strcasecmp($iban_user['lname'], $recipient_lname) === 0) {
            $name_match = true;
        }
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE fname = ? AND lname = ?");
        $stmt->execute([$recipient_fname, $recipient_lname]);
        $user_exists = $stmt->fetch() !== false;
    }

    if (!$iban_user && !$user_exists) {
        $error = "User not found";
    } elseif ($iban_user && !$name_match) {
        $error = "IBAN not matching the provided name";
    } elseif (!$iban_user && $user_exists) {
        $error = "Username not matching IBAN";
    } elseif ($iban_user && $name_match) {
        $to_user_id = $iban_user['id'];
        if ($to_user_id == $source_user_id) {
            $error = "Cannot transfer to yourself.";
        } else {
            $stmt = $pdo->prepare("SELECT balance FROM user_balances WHERE user_id = ? AND currency_id = ?");
            $stmt->execute([$source_user_id, $currency_id]);
            $balance = $stmt->fetchColumn();
            if ($balance === false || $balance < $amount) {
                $error = "Insufficient funds";
            } else {
                if ($amount > 1000) {
                    $desc = "Transfer to user ID $to_user_id, amount $amount";
                    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, type, from_currency_id, to_currency_id, amount, status, description) 
                                            VALUES (?, 'transfer', ?, ?, ?, 'pending', ?)");
                    $stmt->execute([$source_user_id, $currency_id, $currency_id, $amount, $desc]);
                    $success = true;
                    $error = "Transfer over 1000 requires banker approval. Transaction is pending.";
                } else {
                    $pdo->beginTransaction();
                    try {
                        $stmt = $pdo->prepare("UPDATE user_balances SET balance = balance - ? WHERE user_id = ? AND currency_id = ?");
                        $stmt->execute([$amount, $source_user_id, $currency_id]);
                        $stmt = $pdo->prepare("INSERT INTO user_balances (user_id, currency_id, balance) VALUES (?, ?, ?)
                                                ON DUPLICATE KEY UPDATE balance = balance + VALUES(balance)");
                        $stmt->execute([$to_user_id, $currency_id, $amount]);
                        $desc = "Transfer to user ID $to_user_id, amount $amount";
                        $stmt = $pdo->prepare("INSERT INTO transactions (user_id, type, from_currency_id, to_currency_id, amount, status, description) 
                                                VALUES (?, 'transfer', ?, ?, ?, 'completed', ?)");
                        $stmt->execute([$source_user_id, $currency_id, $currency_id, $amount, $desc]);
                        $pdo->commit();
                        $success = true;
                        $error = "Transfer successful!";
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        $error = "Transfer failed: " . $e->getMessage();
                    }
                }
            }
        }
    }
    if ($success) {
        header("Location: transfer.php?id=$source_user_id&msg=" . urlencode($error));
        exit;
    }
}

$pageTitle = "Transfer Money";
require_once 'includes/header.php';
?>

<div class="card" style="max-width: 500px; margin: 0 auto;">
    <h2>Transfer Money</h2>
    <p><strong>Transferring FROM:</strong> <?= htmlspecialchars($source_user['fname'] . ' ' . $source_user['lname']) ?> (ID: <?= $source_user_id ?>)</p>
    <?php if (isset($_GET['msg'])): ?>
        <div class="info"><?= htmlspecialchars($_GET['msg']) ?></div>
    <?php elseif ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($frozen): ?>
        <div class="error">Your account is frozen. You cannot make transfers.</div>
    <?php else: ?>
        <form method="post">
            <div class="form-group">
                <label>Recipient First Name</label>
                <input type="text" name="fname" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Recipient Last Name</label>
                <input type="text" name="lname" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Recipient IBAN</label>
                <input type="text" name="iban" class="form-control" placeholder="BG80BNBG10000000000001" required>
            </div>
            <div class="form-group">
                <label>Currency</label>
                <select name="currency" class="form-control" required>
                    <?php foreach ($currencies as $c): ?>
                        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['code']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Amount</label>
                <input type="number" step="0.01" name="amount" class="form-control" required>
            </div>
            <button type="submit" class="btn">Transfer</button>
        </form>
    <?php endif; ?>
    <p><a href="dashboard.php?id=<?= $source_user_id ?>">Back to Dashboard</a></p>
</div>

<?php require_once 'includes/footer.php'; ?>
