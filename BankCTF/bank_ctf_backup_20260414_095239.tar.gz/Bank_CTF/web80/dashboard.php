<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: login.php');
    exit;
}

$view_user_id = isset($_GET['id']) ? (int)$_GET['id'] : $_SESSION['user_id'];

$pageTitle = "Dashboard";
require_once 'includes/header.php';
require_once 'db_connect.php';

$current_user_id = $_SESSION['user_id'];
$is_owner = ($view_user_id == $current_user_id);

$stmt = $pdo->prepare("SELECT username, email, fname, lname FROM users WHERE id = ?");
$stmt->execute([$view_user_id]);
$view_user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$view_user) {
    echo "<div class='error'>User not found.</div>";
    require_once 'includes/footer.php';
    exit;
}

$full_name = $view_user['fname'] . ' ' . $view_user['lname'];

$stmt = $pdo->prepare("
    SELECT c.id, c.code, c.name, c.type, COALESCE(ub.balance, 0) AS balance
    FROM currencies c
    LEFT JOIN user_balances ub ON c.id = ub.currency_id AND ub.user_id = ?
    ORDER BY c.type DESC, c.code
");
$stmt->execute([$view_user_id]);
$balances = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("
    SELECT t.*, 
           fc.code AS from_currency_code, 
           tc.code AS to_currency_code
    FROM transactions t
    LEFT JOIN currencies fc ON t.from_currency_id = fc.id
    LEFT JOIN currencies tc ON t.to_currency_id = tc.id
    WHERE t.user_id = ?
    ORDER BY t.created_at DESC
    LIMIT 10
");
$stmt->execute([$view_user_id]);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="card">
    <h2><?= htmlspecialchars($full_name) ?>'s Dashboard</h2>
    <p>Username: <?= htmlspecialchars($view_user['username']) ?> | Email: <?= htmlspecialchars($view_user['email']) ?></p>
</div>

<div class="card">
    <h3>Balances</h3>
    <table class="data-table">
        <thead>
            <tr><th>Currency</th><th>Type</th><th>Balance</th></tr>
        </thead>
        <tbody>
            <?php foreach ($balances as $b): ?>
                <tr>
                    <td><?= htmlspecialchars($b['code']) ?> (<?= htmlspecialchars($b['name']) ?>)</td>
                    <td><?= ucfirst(htmlspecialchars($b['type'])) ?></td>
                    <td>
                        <?php if ($b['type'] === 'fiat'): ?>
                            $<?= number_format($b['balance'], 2) ?>
                        <?php else: ?>
                            <?= number_format($b['balance'], 8) ?> <?= htmlspecialchars($b['code']) ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="card">
    <h3>Actions</h3>
    <p>
        <a href="transfer.php?id=<?= $view_user_id ?>" class="btn">Transfer Money</a>
        <a href="exchange.php?id=<?= $view_user_id ?>" class="btn">Exchange Currency</a>
        <a href="deposit.php?id=<?= $view_user_id ?>" class="btn">Deposit</a>
        <a href="profile.php?id=<?= $view_user_id ?>" class="btn">View Profile</a>
    </p>
</div>

<div class="card">
    <h3>Recent Transactions</h3>
    <?php if (empty($transactions)): ?>
        <p>No transactions yet.</p>
    <?php else: ?>
        <table class="data-table">
            <thead>
                <tr><th>Date</th><th>Type</th><th>Details</th><th>Amount</th></tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $tx): ?>
                    <tr>
                        <td><?= date('Y-m-d H:i', strtotime($tx['created_at'])) ?></td>
                        <td><?= ucfirst(htmlspecialchars($tx['type'])) ?></td>
                        <td>
                            <?php
                            switch ($tx['type']) {
                                case 'transfer':
                                    echo "Transfer of " . number_format($tx['amount'], 2) . " " . htmlspecialchars($tx['to_currency_code']);
                                    break;
                                case 'exchange':
                                    echo "Exchanged " . number_format($tx['amount'], 8) . " " . htmlspecialchars($tx['from_currency_code']) .
                                         " to " . number_format($tx['amount'] * $tx['rate'], 8) . " " . htmlspecialchars($tx['to_currency_code']);
                                    break;
                                case 'deposit':
                                    echo "Deposit of " . number_format($tx['amount'], 2) . " " . htmlspecialchars($tx['to_currency_code']);
                                    break;
                                default:
                                    echo htmlspecialchars($tx['description']);
                            }
                            ?>
                        </td>
                        <td>
                            <?php
                            if ($tx['type'] === 'exchange') {
                                echo number_format($tx['amount'] * $tx['rate'], 8) . " " . htmlspecialchars($tx['to_currency_code']);
                            } elseif ($tx['type'] === 'transfer') {
                                echo number_format($tx['amount'], 2) . " " . htmlspecialchars($tx['to_currency_code']);
                            } elseif ($tx['type'] === 'deposit') {
                                echo "+ " . number_format($tx['amount'], 2) . " " . htmlspecialchars($tx['to_currency_code']);
                            } else {
                                echo number_format($tx['amount'], 8) . " " . htmlspecialchars($tx['from_currency_code']);
                            }
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>
