<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$view_user_id = isset($_GET['id']) ? (int)$_GET['id'] : $_SESSION['user_id'];

$pageTitle = "My Profile";
require_once 'includes/header.php';
require_once 'db_connect.php';

$current_user_id = $_SESSION['user_id'];
$is_owner = ($view_user_id == $current_user_id);

$stmt = $pdo->prepare("SELECT username, email, fname, lname, iban, created_at FROM users WHERE id = ?");
$stmt->execute([$view_user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "<div class='error'>User not found.</div>";
    require_once 'includes/footer.php';
    exit;
}
?>

<style>
    .avatar-circle {
        width: 120px;
        height: 120px;
        background: #1e2a3a;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1rem auto;
        border: 3px solid #2ecc71;
        transition: 0.3s;
    }
    .avatar-circle i {
        font-size: 4rem;
        color: #88aacc;
    }
    .avatar-circle:hover {
        transform: scale(1.05);
        border-color: #ffaa44;
        box-shadow: 0 0 15px rgba(46,204,113,0.5);
    }
    .coming-soon {
        background: #ffaa44;
        color: #0a1a24;
        font-size: 0.7rem;
        padding: 2px 8px;
        border-radius: 20px;
        display: inline-block;
    }
    .profile-info p {
        margin: 0.5rem 0;
        padding: 0.5rem;
        border-bottom: 1px solid rgba(46,204,113,0.2);
    }
    .profile-info strong {
        display: inline-block;
        width: 100px;
        color: #2ecc71;
    }
</style>

<div class="card" style="max-width: 550px; margin: 0 auto; text-align: center;">
    <div class="avatar-circle">
        <i class="fas fa-user"></i>
    </div>
    <div class="coming-soon" style="margin-bottom: 1rem;">Upload Avatar (coming soon)</div>
    
    <h2><?= htmlspecialchars($user['fname'] . ' ' . $user['lname']) ?></h2>
    
    <div class="profile-info" style="text-align: left; margin-top: 1.5rem;">
        <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
        <p><strong>IBAN:</strong> <code><?= htmlspecialchars($user['iban']) ?></code></p>
        <p><strong>Member since:</strong> <?= date('d M Y', strtotime($user['created_at'])) ?></p>
    </div>
    
    <div style="margin-top: 1.5rem;">
        <?php if ($is_owner): ?>
            <a href="edit_profile.php" class="btn">Edit Profile</a>
        <?php endif; ?>
        <a href="dashboard.php?id=<?= $view_user_id ?>" class="btn btn-outline">Back to Dashboard</a>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
