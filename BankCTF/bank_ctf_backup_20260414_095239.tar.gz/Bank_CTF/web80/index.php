<?php
$pageTitle = "Home";
require_once 'includes/header.php';
require_once 'db_connect.php';

$userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$transactionCount = $pdo->query("SELECT COUNT(*) FROM transactions")->fetchColumn();
$accountCount = $pdo->query("SELECT COUNT(*) FROM accounts")->fetchColumn();

$rates = $pdo->query("
    SELECT c.code, c.name, c.type, c.exchange_rate_to_usd 
    FROM currencies c 
    ORDER BY c.type DESC, c.code
")->fetchAll(PDO::FETCH_ASSOC);

$lastUpdate = $pdo->query("SELECT MAX(updated_at) FROM exchange_rates")->fetchColumn();
$lastUpdate = $lastUpdate ? date('d.m.Y H:i', strtotime($lastUpdate)) : 'днес';
?>

<style>
    .hover-effect {
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }
    .hover-effect:hover {
        border-color: #2ecc71;
        transform: scale(1.02);
        box-shadow: 0 0 15px rgba(46, 204, 113, 0.5);
        cursor: pointer;
    }
    .coming-soon {
        display: inline-block;
        background: #ffaa44;
        color: #0a1a24;
        font-size: 0.7rem;
        padding: 2px 6px;
        border-radius: 20px;
        margin-left: 8px;
        vertical-align: middle;
    }
    .product-card, .stat-card, .card, .data-table tr {
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }
    .data-table tr:hover {
        background: rgba(46, 204, 113, 0.1);
        transform: scale(1.01);
        border-color: #2ecc71;
    }
</style>

<div class="hero-section" style="background: linear-gradient(135deg, #0a2f3a 0%, #0a1f2a 100%); border-radius: 20px; padding: 3rem 2rem; margin-bottom: 2rem; text-align: center;">
    <h1 style="font-size: 3rem; margin-bottom: 1rem;">Welcome to MegaBank</h1>
    <p style="font-size: 1.2rem; max-width: 600px; margin: 0 auto 2rem auto;">Your trusted partner in secure banking. Manage your finances, exchange currencies, and transfer money with ease.</p>
    <?php if (!isset($_SESSION['user_id'])): ?>
        <a href="login.php" class="btn">Login</a>
        <a href="register.php" class="btn btn-outline" style="margin-left: 1rem;">Register</a>
    <?php else: ?>
        <a href="dashboard.php" class="btn">Go to Dashboard</a>
    <?php endif; ?>
</div>

<div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
    <div class="stat-card hover-effect" style="background: rgba(10,26,36,0.8); backdrop-filter: blur(8px); border-radius: 15px; padding: 1.5rem; text-align: center;">
        <div style="font-size: 2rem; font-weight: bold; color: #2ecc71;"><?= number_format($userCount) ?></div>
        <div>Happy Clients</div>
    </div>
    <div class="stat-card hover-effect" style="background: rgba(10,26,36,0.8); backdrop-filter: blur(8px); border-radius: 15px; padding: 1.5rem; text-align: center;">
        <div style="font-size: 2rem; font-weight: bold; color: #2ecc71;"><?= number_format($transactionCount) ?></div>
        <div>Transactions Processed</div>
    </div>
    <div class="stat-card hover-effect" style="background: rgba(10,26,36,0.8); backdrop-filter: blur(8px); border-radius: 15px; padding: 1.5rem; text-align: center;">
        <div style="font-size: 2rem; font-weight: bold; color: #2ecc71;"><?= number_format($accountCount) ?></div>
        <div>Active Accounts</div>
    </div>
</div>

<div class="card hover-effect">
    <h3>Exchange Rates (vs USD) <span class="coming-soon">More currencies coming soon</span></h3>
    <p style="font-size: 0.8rem; margin-bottom: 1rem;">Last updated: <?= $lastUpdate ?></p>
    <table class="data-table">
        <thead>
            <tr><th>Currency</th><th>Name</th><th>Type</th><th>Rate (1 USD)</th></tr>
        </thead>
        <tbody>
            <?php foreach ($rates as $r): ?>
                <tr class="hover-effect">
                    <td><strong><?= htmlspecialchars($r['code']) ?></strong></td>
                    <td><?= htmlspecialchars($r['name']) ?></td>
                    <td><?= ucfirst(htmlspecialchars($r['type'])) ?></td>
                    <td><?= number_format($r['exchange_rate_to_usd'], 4) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="products-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; margin: 2rem 0;">
    <div class="product-card hover-effect" style="background: rgba(10,26,36,0.8); border-radius: 15px; padding: 1.5rem;">
        <h4><i class="fas fa-credit-card"></i> Credit Cards</h4>
        <p>Low interest rates, cashback rewards, and fraud protection.</p>
    </div>
    <div class="product-card hover-effect" style="background: rgba(10,26,36,0.8); border-radius: 15px; padding: 1.5rem;">
        <h4><i class="fas fa-chart-line"></i> Investments <span class="coming-soon">Coming Soon</span></h4>
        <p>Stocks, bonds, and crypto portfolios tailored to your goals.</p>
    </div>
    <div class="product-card hover-effect" style="background: rgba(10,26,36,0.8); border-radius: 15px; padding: 1.5rem;">
        <h4><i class="fas fa-hand-holding-usd"></i> Loans</h4>
        <p>Personal, mortgage, and business loans with flexible terms.</p>
    </div>
</div>

<div class="card hover-effect">
    <h3>Why MegaBank?</h3>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
        <div class="hover-effect" style="padding: 0.5rem; border-radius: 10px;">
            <i class="fas fa-shield-alt" style="color: #2ecc71;"></i>
            <strong>Secure Banking</strong>
            <p>256-bit encryption and real-time fraud monitoring.</p>
        </div>
        <div class="hover-effect" style="padding: 0.5rem; border-radius: 10px;">
            <i class="fas fa-globe" style="color: #2ecc71;"></i>
            <strong>Global Access</strong>
            <p>Manage your finances from anywhere, anytime.</p>
        </div>
        <div class="hover-effect" style="padding: 0.5rem; border-radius: 10px;">
            <i class="fas fa-clock" style="color: #2ecc71;"></i>
            <strong>24/7 Support</strong>
            <p>Dedicated customer service available round the clock.</p>
        </div>
        <div class="hover-effect" style="padding: 0.5rem; border-radius: 10px;">
            <i class="fas fa-chart-simple" style="color: #2ecc71;"></i>
            <strong>Competitive Rates</strong>
            <p>High interest savings and low loan APRs.</p>
        </div>
    </div>
</div>

<div class="card hover-effect">
    <h3>Latest Offers</h3>
    <ul>
        <li>🎁 New customers get a $50 welcome bonus after first deposit.</li>
        <li>📈 0% commission on crypto trades for the first month <span class="coming-soon">Crypto expansion soon</span></li>
        <li>🏦 2% cashback on all credit card purchases.</li>
        <li>📊 Stock trading platform – <span class="coming-soon">Coming 2025</span></li>
    </ul>
</div>

<footer style="margin-top: 2rem; text-align: center; padding: 1rem; border-top: 1px solid #2ecc71;">
    <p>&copy; <?= date('Y') ?> MegaBank – Secure Online Banking</p>
    <p><small>IBAN: BG80BNBG12345678901234 | SWIFT: MEGABANK | Contact: support@megabank.com</small></p>
</footer>

<?php require_once 'includes/footer.php'; ?>
