<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$pageTitle = "Edit Profile";
require_once 'includes/header.php';
require_once 'db_connect.php';

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

$stmt = $pdo->prepare("SELECT fname, lname, email FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = trim($_POST['fname'] ?? '');
    $lname = trim($_POST['lname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (empty($fname) || empty($lname) || empty($email)) {
        $error = "First name, last name and email are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address.";
    } elseif (!empty($password) && $password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        if (!empty($password)) {
            $hashed = md5($password);
            $stmt = $pdo->prepare("UPDATE users SET fname = ?, lname = ?, email = ?, password = ? WHERE id = ?");
            $stmt->execute([$fname, $lname, $email, $hashed, $user_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET fname = ?, lname = ?, email = ? WHERE id = ?");
            $stmt->execute([$fname, $lname, $email, $user_id]);
        }
        $success = "Profile updated successfully.";
        $user['fname'] = $fname;
        $user['lname'] = $lname;
        $user['email'] = $email;
    }
}
?>

<style>
    .edit-card {
        max-width: 500px;
        margin: 0 auto;
        transition: all 0.3s ease;
    }
    .edit-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }
    .form-group {
        margin-bottom: 1rem;
    }
    label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 500;
        color: #2ecc71;
    }
    input {
        width: 100%;
        padding: 0.8rem;
        background: #1e2a3a;
        border: 1px solid #2ecc71;
        border-radius: 8px;
        color: #fff;
        transition: 0.3s;
    }
    input:focus {
        outline: none;
        border-color: #ffaa44;
        box-shadow: 0 0 8px #ffaa44;
    }
    .btn-group {
        display: flex;
        gap: 1rem;
        margin-top: 1.5rem;
    }
    .error {
        background: rgba(231,76,60,0.2);
        border-left: 4px solid #e74c3c;
        padding: 0.8rem;
        margin-bottom: 1rem;
        border-radius: 8px;
    }
    .success {
        background: rgba(46,204,113,0.2);
        border-left: 4px solid #2ecc71;
        padding: 0.8rem;
        margin-bottom: 1rem;
        border-radius: 8px;
    }
</style>

<div class="card edit-card">
    <h2>Edit Profile</h2>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <form method="post">
        <div class="form-group">
            <label>First Name</label>
            <input type="text" name="fname" value="<?= htmlspecialchars($user['fname']) ?>" required>
        </div>
        <div class="form-group">
            <label>Last Name</label>
            <input type="text" name="lname" value="<?= htmlspecialchars($user['lname']) ?>" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
        </div>
        <div class="form-group">
            <label>New Password (leave blank to keep current)</label>
            <input type="password" name="password">
        </div>
        <div class="form-group">
            <label>Confirm New Password</label>
            <input type="password" name="confirm_password">
        </div>
        <div class="btn-group">
            <button type="submit" class="btn">Save Changes</button>
            <a href="profile.php" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>
