<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$pageTitle = $pageTitle ?? 'MegaBank';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MegaBank | <?= htmlspecialchars($pageTitle) ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a2f3a 0%, #0a1f2a 100%);
            color: #eef4ff;
            min-height: 100vh;
        }
        /* Navigation */
        .navbar {
            background: #0a1a24;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            border-bottom: 3px solid #2ecc71;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        .navbar-brand {
            font-size: 1.8rem;
            font-weight: bold;
            color: #2ecc71;
            text-decoration: none;
            letter-spacing: 2px;
        }
        .navbar-brand span {
            color: #3498db;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            color: #ffffff;
            text-decoration: none;
            font-weight: 500;
            transition: 0.3s;
            padding: 0.5rem 0;
        }
        .nav-links a:hover {
            color: #2ecc71;
            border-bottom: 2px solid #2ecc71;
        }
        /* Container */
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        /* Cards, buttons, forms */
        .card {
            background: rgba(10, 26, 36, 0.8);
            backdrop-filter: blur(8px);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid rgba(46, 204, 113, 0.3);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .btn {
            background: #2ecc71;
            color: #0a1a24;
            border: none;
            padding: 0.7rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            transition: 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover {
            background: #27ae60;
            transform: translateY(-2px);
        }
        .btn-outline {
            background: transparent;
            border: 2px solid #2ecc71;
            color: #2ecc71;
        }
        .btn-outline:hover {
            background: #2ecc71;
            color: #0a1a24;
        }
        input, select, textarea {
            width: 100%;
            padding: 0.8rem;
            margin: 0.5rem 0;
            background: rgba(255,255,255,0.1);
            border: 1px solid #2ecc71;
            border-radius: 8px;
            color: white;
        }
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 5px #3498db;
        }
        .error {
            background: rgba(231, 76, 60, 0.2);
            border-left: 4px solid #e74c3c;
            padding: 0.8rem;
            margin-bottom: 1rem;
        }
        .success {
            background: rgba(46, 204, 113, 0.2);
            border-left: 4px solid #2ecc71;
            padding: 0.8rem;
            margin-bottom: 1rem;
        }
        footer {
            text-align: center;
            padding: 1.5rem;
            margin-top: 3rem;
            background: #0a1a24;
            color: #7f8c8d;
            border-top: 1px solid #2ecc71;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: rgba(10,26,36,0.6);
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #2ecc71;
        }
        th {
            background: #0e2a38;
            color: #2ecc71;
        }
        @media (max-width: 768px) {
            .navbar { flex-direction: column; text-align: center; }
            .nav-links { justify-content: center; }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="index.php" class="navbar-brand">
            <span>Mega</span>Bank
        </a>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'user'): ?>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="transfer.php">Transfer</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="logout.php">Logout</a></li>
            <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'banker'): ?>
                <li><a href="dashboard.php">Banker Panel</a></li>
                <li><a href="logout.php">Logout</a></li>
            <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                <li><a href="dashboard.php">Admin Panel</a></li>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <main class="container">
