    </main>
    <footer>
        <p>&copy; <?= date('Y') ?> MegaBank – Secure Online Banking</p>
    </footer>
</body>
</html>
