<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: login.php');
    exit;
}
$pageTitle = "Deposit";
require_once 'includes/header.php';
require_once 'db_connect.php';

$error = '';
$success = '';
$user_id = $_SESSION['user_id'];


$currencies = $pdo->query("SELECT id, code FROM currencies WHERE type='fiat'")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = (float)$_POST['amount'];
    $currency_id = (int)$_POST['currency'];
    $card_number = $_POST['card_number']; 

  
    if (strlen($card_number) < 16) {
        $error = "Invalid card number.";
    } else {
        $pdo->beginTransaction();
        try {
            
            $stmt = $pdo->prepare("INSERT INTO user_balances (user_id, currency_id, balance) VALUES (?, ?, ?)
                                    ON DUPLICATE KEY UPDATE balance = balance + VALUES(balance)");
            $stmt->execute([$user_id, $currency_id, $amount]);
            
            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, type, to_currency_id, amount, description) 
                                    VALUES (?, 'deposit', ?, ?, ?)");
            $stmt->execute([$user_id, $currency_id, $amount, "Card deposit: $card_number"]);
            $pdo->commit();
            $success = "Deposit of $amount added to your account.";
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Deposit failed: " . $e->getMessage();
        }
    }
}
?>
<h2>Deposit Money</h2>
<?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<form method="post">
    <div class="form-group">
        <label>Currency</label>
        <select name="currency" required>
            <?php foreach ($currencies as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['code']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Amount</label>
        <input type="number" step="0.01" name="amount" required>
    </div>
    <div class="form-group">
        <label>Card Number</label>
        <input type="text" name="card_number" placeholder="1234-5678-9012-3456" required>
    </div>
    <button type="submit" class="btn">Deposit</button>
</form>
<?php require_once 'includes/footer.php'; ?>
