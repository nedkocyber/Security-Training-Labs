<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$pageTitle = "Register";
require_once 'includes/header.php';
require_once 'db_connect.php';

$error = '';
$success = '';
$fname = $lname = $username = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = trim($_POST['fname'] ?? '');
    $lname = trim($_POST['lname'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $b = isset($_POST['b']) && $_POST['b'] == '1' ? 1 : 0;

    if (empty($fname) || empty($lname) || empty($username) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        if ($b == 1) {
            $stmt = $pdo->prepare("SELECT id FROM bankers WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            if ($stmt->fetch()) {
                $error = "Banker username or email already exists.";
            } else {
                $hashed = hash('sha512', $password);
                $stmt = $pdo->prepare("INSERT INTO bankers (username, password, email, full_name) VALUES (?, ?, ?, ?)");
                $full_name = "$fname $lname";
                if ($stmt->execute([$username, $hashed, $email, $full_name])) {
                    $success = "Banker registration successful! You can now <a href='../banker8080/login.php'>login to banker portal</a>.";
                    $fname = $lname = $username = $email = '';
                } else {
                    $error = "Banker registration failed. Please try again.";
                }
            }
        } else {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            if ($stmt->fetch()) {
                $error = "Username or email already exists.";
            } else {
                $hashed = md5($password);
                do {
                    $iban = 'BG80BNBG' . str_pad(random_int(0, 9999999999999999), 16, '0', STR_PAD_LEFT);
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE iban = ?");
                    $stmt->execute([$iban]);
                } while ($stmt->fetch());
                
                $pdo->beginTransaction();
                try {
                    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, fname, lname, iban) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$username, $hashed, $email, $fname, $lname, $iban]);
                    $user_id = $pdo->lastInsertId();
                    $stmt = $pdo->prepare("INSERT INTO accounts (user_id, balance) VALUES (?, 0.00)");
                    $stmt->execute([$user_id]);
                    $currencies = $pdo->query("SELECT id FROM currencies")->fetchAll(PDO::FETCH_COLUMN);
                    if ($currencies) {
                        $insert = $pdo->prepare("INSERT IGNORE INTO user_balances (user_id, currency_id, balance) VALUES (?, ?, 0)");
                        foreach ($currencies as $cid) {
                            $insert->execute([$user_id, $cid]);
                        }
                    }
                    $pdo->commit();
                    $success = "Registration successful! You can now <a href='login.php'>login</a>.";
                    $fname = $lname = $username = $email = '';
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $error = "Registration failed. Please try again.";
                }
            }
        }
    }
}
?>

<div class="card" style="max-width: 500px; margin: 0 auto;">
    <h2>Create an Account</h2>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="success"><?= $success ?></div>
    <?php endif; ?>
    <form method="post">
        <div class="form-group">
            <label>First Name</label>
            <input type="text" name="fname" class="form-control" value="<?= htmlspecialchars($fname) ?>" required>
        </div>
        <div class="form-group">
            <label>Last Name</label>
            <input type="text" name="lname" class="form-control" value="<?= htmlspecialchars($lname) ?>" required>
        </div>
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($username) ?>" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($email) ?>" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="confirm_password" class="form-control" required>
        </div>
        <input type="hidden" name="b" value="0">
        <button type="submit" class="btn">Register</button>
    </form>
    <p>Already have an account? <a href="login.php">Login here</a></p>
</div>

<?php require_once 'includes/footer.php'; ?>
