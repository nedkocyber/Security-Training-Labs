#!/bin/bash
set -e

echo "[*] Stopping containers and removing everything sudo rm -rf / && (volumes)..."
docker compose down -v --rmi all --remove-orphans

echo "[*] Rebuilding and starting fresh containers..."
docker compose up -d --build

echo "[*] Waiting for database to be ready..."
until docker exec bank_db mariadb -u root -prootpass -e "SELECT 1" &> /dev/null; do
    echo "Waiting for database..."
    sleep 2
done

echo "[+] Reset completed successfully!"
echo "   - User portal: http://localhost:80"
echo "   - Banker portal: http://localhost:8080"
echo "   - Admin portal: http://localhost:8081"
