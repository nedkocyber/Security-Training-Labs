<?php
session_start();
if (!isset($_SESSION['banker_id']) || $_SESSION['role'] !== 'banker') {
    header('Location: login.php');
    exit;
}

$pageTitle = "Banker Dashboard";
require_once 'includes/header.php';
require_once 'db_connect.php';

$error = '';
$success = '';

$users = $pdo->query("
    SELECT u.id, u.username, u.fname, u.lname, u.email, a.balance, a.frozen
    FROM users u
    LEFT JOIN accounts a ON u.id = a.user_id
    ORDER BY u.id
")->fetchAll(PDO::FETCH_ASSOC);

$pending = $pdo->query("
    SELECT t.*, 
           u.username AS sender_username,
           u.fname AS sender_fname,
           u.lname AS sender_lname,
           fc.code AS from_currency_code,
           tc.code AS to_currency_code
    FROM transactions t
    JOIN users u ON t.user_id = u.id
    LEFT JOIN currencies fc ON t.from_currency_id = fc.id
    LEFT JOIN currencies tc ON t.to_currency_id = tc.id
    WHERE t.status = 'pending'
    ORDER BY t.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($pending as &$tx) {
    $receiver_id = null;
    if (preg_match('/to user ID (\d+)/', $tx['description'], $matches)) {
        $receiver_id = (int)$matches[1];
    }
    if ($receiver_id) {
        $stmt = $pdo->prepare("SELECT id, username, fname, lname FROM users WHERE id = ?");
        $stmt->execute([$receiver_id]);
        $receiver = $stmt->fetch(PDO::FETCH_ASSOC);
        $tx['receiver_id'] = $receiver['id'] ?? null;
        $tx['receiver_username'] = $receiver['username'] ?? 'Unknown';
        $tx['receiver_fname'] = $receiver['fname'] ?? '';
        $tx['receiver_lname'] = $receiver['lname'] ?? '';
    } else {
        $tx['receiver_id'] = null;
        $tx['receiver_username'] = 'Unknown';
        $tx['receiver_fname'] = '';
        $tx['receiver_lname'] = '';
    }
}
unset($tx);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['freeze'])) {
        $user_id = (int)$_POST['user_id'];
        $stmt = $pdo->prepare("UPDATE accounts SET frozen = 1 WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $success = "Account frozen.";
    } elseif (isset($_POST['unfreeze'])) {
        $user_id = (int)$_POST['user_id'];
        $stmt = $pdo->prepare("UPDATE accounts SET frozen = 0 WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $success = "Account unfrozen.";
    } elseif (isset($_POST['edit_user'])) {
        $user_id = (int)$_POST['user_id'];
        $fname = trim($_POST['fname']);
        $lname = trim($_POST['lname']);
        $email = trim($_POST['email']);
        $stmt = $pdo->prepare("UPDATE users SET fname = ?, lname = ?, email = ? WHERE id = ?");
        $stmt->execute([$fname, $lname, $email, $user_id]);
        $success = "User updated.";
    } elseif (isset($_POST['approve_tx'])) {
        $tx_id = (int)$_POST['tx_id'];
        $stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = ? AND status = 'pending'");
        $stmt->execute([$tx_id]);
        $tx = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($tx) {
            preg_match('/to user ID (\d+)/', $tx['description'], $matches);
            $to_user_id = $matches[1] ?? null;
            if ($to_user_id) {
                $pdo->beginTransaction();
                try {
                    $stmt = $pdo->prepare("UPDATE user_balances SET balance = balance - ? WHERE user_id = ? AND currency_id = ?");
                    $stmt->execute([$tx['amount'], $tx['user_id'], $tx['from_currency_id']]);
                    $stmt = $pdo->prepare("INSERT INTO user_balances (user_id, currency_id, balance) VALUES (?, ?, ?)
                                            ON DUPLICATE KEY UPDATE balance = balance + VALUES(balance)");
                    $stmt->execute([$to_user_id, $tx['to_currency_id'], $tx['amount']]);
                    $stmt = $pdo->prepare("UPDATE transactions SET status = 'completed' WHERE id = ?");
                    $stmt->execute([$tx_id]);
                    $pdo->commit();
                    $success = "Transaction #$tx_id approved and completed.";
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $error = "Approval failed: " . $e->getMessage();
                }
            } else {
                $error = "Could not determine recipient.";
            }
        } else {
            $error = "Transaction not found or already processed.";
        }
    } elseif (isset($_POST['reject_tx'])) {
        $tx_id = (int)$_POST['tx_id'];
        $stmt = $pdo->prepare("UPDATE transactions SET status = 'rejected' WHERE id = ? AND status = 'pending'");
        $stmt->execute([$tx_id]);
        $success = "Transaction #$tx_id rejected.";
    }
}
?>

<style>
    .banker-table, .pending-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 1rem;
    }
    .banker-table th, .banker-table td, .pending-table th, .pending-table td {
        padding: 10px;
        border-bottom: 1px solid #ffaa44;
        text-align: left;
    }
    .banker-table th, .pending-table th {
        background: #1a2a3a;
        color: #ffaa44;
    }
    .btn-sm {
        background: #ffaa44;
        border: none;
        color: #0a1a24;
        padding: 4px 10px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 0.8rem;
    }
    .btn-sm:hover {
        background: #ffcc66;
    }
    .btn-danger {
        background: #e74c3c;
        color: white;
    }
    .btn-success {
        background: #2ecc71;
        color: #0a1a24;
    }
    .inline-form {
        display: inline;
    }
    input, select {
        padding: 5px;
        background: #1e2a3a;
        border: 1px solid #ffaa44;
        border-radius: 5px;
        color: white;
    }
    .section-title {
        margin-top: 2rem;
        border-left: 4px solid #ffaa44;
        padding-left: 1rem;
    }
</style>

<div class="card">
    <h2>Banker Dashboard</h2>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <h3 class="section-title">Pending Approvals (Amount > 1000)</h3>
    <?php if (empty($pending)): ?>
        <p>No pending transactions.</p>
    <?php else: ?>
        <table class="pending-table">
            <thead>
                <tr><th>ID</th><th>Sender</th><th>Recipient</th><th>Amount</th><th>Currency</th><th>Date</th><th>Action</th></tr>
            </thead>
            <tbody>
                <?php foreach ($pending as $tx): ?>
                <tr>
                    <td><?= $tx['id'] ?></td>
                    <td><?= htmlspecialchars($tx['sender_fname'] . ' ' . $tx['sender_lname']) ?> (ID <?= $tx['user_id'] ?>)</td>
                    <td><?= htmlspecialchars($tx['receiver_fname'] . ' ' . $tx['receiver_lname']) ?> (ID <?= $tx['receiver_id'] ?>)</td>
                    <td><?= number_format($tx['amount'], 2) ?> <?= htmlspecialchars($tx['from_currency_code']) ?></td>
                    <td><?= htmlspecialchars($tx['from_currency_code']) ?> → <?= htmlspecialchars($tx['to_currency_code']) ?></td>
                    <td><?= date('Y-m-d H:i', strtotime($tx['created_at'])) ?></td>
                    <td>
                        <form method="post" class="inline-form">
                            <input type="hidden" name="tx_id" value="<?= $tx['id'] ?>">
                            <button type="submit" name="approve_tx" class="btn-sm btn-success">Approve</button>
                            <button type="submit" name="reject_tx" class="btn-sm btn-danger">Reject</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <h3 class="section-title">Customer Accounts</h3>
    <table class="banker-table">
        <thead>
            <tr><th>ID</th><th>Username</th><th>Full Name</th><th>Email</th><th>Balance</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user['id'] ?></td>
                <td><?= htmlspecialchars($user['username']) ?></td>
                <td>
                    <form method="post" class="inline-form">
                        <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                        <input type="text" name="fname" value="<?= htmlspecialchars($user['fname']) ?>" size="10">
                        <input type="text" name="lname" value="<?= htmlspecialchars($user['lname']) ?>" size="10">
                        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" size="15">
                        <button type="submit" name="edit_user" class="btn-sm">Update</button>
                    </form>
                 </td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td>$<?= number_format($user['balance'], 2) ?></td>
                <td><?= $user['frozen'] ? 'Frozen' : 'Active' ?></td>
                <td>
                    <?php if ($user['frozen']): ?>
                        <form method="post" class="inline-form">
                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                            <button type="submit" name="unfreeze" class="btn-sm btn-success">Unfreeze</button>
                        </form>
                    <?php else: ?>
                        <form method="post" class="inline-form">
                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                            <button type="submit" name="freeze" class="btn-sm btn-danger">Freeze</button>
                        </form>
                    <?php endif; ?>
                 </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <p><a href="logout.php" class="btn">Logout</a></p>
</div>

<?php require_once 'includes/footer.php'; ?>
