<?php
$ip = $_SERVER['REMOTE_ADDR'];
if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACCESS DENIED</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background: #0a0a0a;
            background-image: radial-gradient(circle at 10% 20%, rgba(80,0,0,0.3) 0%, #000000 90%);
            font-family: 'Courier New', monospace;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            overflow: hidden;
            animation: pulse 6s infinite alternate;
        }
        @keyframes pulse {
            0% { background-color: #0a0a0a; }
            100% { background-color: #2a0505; }
        }
        .container {
            text-align: center;
            max-width: 700px;
            padding: 2rem;
            border: 2px solid #ff0000;
            box-shadow: 0 0 40px rgba(255,0,0,0.4), inset 0 0 20px rgba(255,0,0,0.1);
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(4px);
            border-radius: 12px;
            animation: borderFlicker 1.2s infinite;
            z-index: 2;
        }
        @keyframes borderFlicker {
            0% { border-color: #ff0000; box-shadow: 0 0 30px rgba(255,0,0,0.5); }
            50% { border-color: #aa0000; box-shadow: 0 0 15px rgba(255,0,0,0.2); }
            100% { border-color: #ff0000; box-shadow: 0 0 30px rgba(255,0,0,0.5); }
        }
        .icon {
            font-size: 5rem;
            margin-bottom: 1rem;
            animation: shake 0.4s infinite alternate;
        }
        @keyframes shake {
            from { transform: translateX(-5px); }
            to { transform: translateX(5px); }
        }
        h1 {
            font-size: 2rem;
            color: #ff3333;
            text-transform: uppercase;
            letter-spacing: 4px;
            margin-bottom: 1.5rem;
            text-shadow: 0 0 8px #ff0000;
        }
        .message {
            font-size: 1.1rem;
            color: #ff8888;
            line-height: 1.6;
            margin: 1.5rem 0;
            border-top: 1px dashed #aa0000;
            border-bottom: 1px dashed #aa0000;
            padding: 1rem 0;
        }
        .ip-box {
            background: #1f1f1f;
            padding: 0.8rem;
            border-radius: 6px;
            font-family: monospace;
            font-size: 1.2rem;
            color: #ff8888;
            margin: 1rem 0;
            word-break: break-all;
            border-left: 4px solid #ff0000;
            text-align: left;
        }
        .blink {
            animation: blink 1s step-end infinite;
        }
        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0; }
        }
        .footer {
            margin-top: 1.5rem;
            font-size: 0.7rem;
            color: #660000;
        }
        .glitch {
            position: relative;
            animation: glitchText 2s infinite;
        }
        @keyframes glitchText {
            0% { transform: skew(0deg, 0deg); opacity: 1; }
            95% { transform: skew(0deg, 0deg); opacity: 1; }
            96% { transform: skew(2deg, -1deg); opacity: 0.9; }
            97% { transform: skew(-1deg, 1deg); opacity: 0.8; }
            98% { transform: skew(0deg, 0deg); opacity: 1; }
        }
        .scan-line {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to bottom, transparent 0%, rgba(255,0,0,0.05) 50%, transparent 100%);
            pointer-events: none;
            z-index: 10;
            animation: scan 6s linear infinite;
        }
        @keyframes scan {
            0% { transform: translateY(-100%); }
            100% { transform: translateY(100%); }
        }
    </style>
</head>
<body>
    <div class="scan-line"></div>
    <div class="container">
        <div class="icon">⚠️</div>
        <h1 class="glitch">ACCESS DENIED</h1>
        <div class="message">
            You are not authorized to view this resource.<br>
            Please leave immediately.<br>
            This incident will be reported<br>
            and your IP will be blacklisted<br>
            <span class="blink">as soon as possible.</span>
        </div>
        <div class="ip-box">
            <span style="color:#ff6666;">YOUR IP: </span>
            <?= htmlspecialchars($ip) ?>
            <span style="display:block; margin-top:5px; font-size:0.8rem;">✓ LOGGED & REPORTED</span>
        </div>
        <div class="footer">
            [ SYSTEM LOCKDOWN IN PROGRESS ]<br>
            ALL ACTIVITIES ARE MONITORED
        </div>
    </div>
    <script>
        setInterval(() => {
            const title = document.querySelector('h1');
            if (title) {
                title.style.textShadow = `0 0 ${Math.random() * 20 + 5}px #ff0000`;
                setTimeout(() => {
                    title.style.textShadow = '0 0 8px #ff0000';
                }, 150);
            }
        }, 700);
    </script>
</body>
</html>
