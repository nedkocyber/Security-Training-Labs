<?php
session_start();

if (isset($_SESSION['banker_id']) && $_SESSION['role'] === 'banker') {
    header('Location: dashboard.php');
    exit;
}

$max_attempts = 3;
$lockout_time = 20;

if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
}
if (!isset($_SESSION['locked_until'])) {
    $_SESSION['locked_until'] = 0;
}

$now = time();
$is_locked = ($_SESSION['locked_until'] > $now);
$error = '';
$username_entered = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_locked) {
    require_once 'db_connect.php';
    $username_entered = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT id, username, password FROM bankers WHERE username = ?");
    $stmt->execute([$username_entered]);
    $banker = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$banker) {
        $error = "Wrong username AND password!";
        $_SESSION['login_attempts']++;
    } else {
        if (hash('sha512', $password) === $banker['password']) {
            $_SESSION['login_attempts'] = 0;
            $_SESSION['locked_until'] = 0;
            $_SESSION['banker_id'] = $banker['id'];
            $_SESSION['username'] = $banker['username'];
            $_SESSION['role'] = 'banker';
            header('Location: dashboard.php');
            exit;
        } else {
            $error = "Wrong username or password";
            $_SESSION['login_attempts']++;
        }
    }

    if ($_SESSION['login_attempts'] >= $max_attempts) {
        $_SESSION['locked_until'] = $now + $lockout_time;
        $_SESSION['login_attempts'] = 0;
        $error = "Account locked for {$lockout_time} seconds because too many invalid login attempts.";
    }
}

if ($is_locked) {
    $remaining = $_SESSION['locked_until'] - $now;
    $error = "Account locked for {$remaining} seconds because too many invalid login attempts.";
}

$pageTitle = "Banker Login";
require_once 'includes/header.php';
?>

<style>
    .login-container {
        max-width: 400px;
        margin: 2rem auto;
        background: rgba(26,42,58,0.8);
        backdrop-filter: blur(8px);
        border-radius: 20px;
        padding: 2rem;
        border: 1px solid #ffaa44;
        box-shadow: 0 0 20px rgba(0,0,0,0.3);
    }
    h2 {
        text-align: center;
        color: #ffaa44;
        margin-bottom: 1.5rem;
    }
    .form-group {
        margin-bottom: 1rem;
    }
    label {
        display: block;
        margin-bottom: 0.5rem;
        color: #ffaa44;
        font-weight: 500;
    }
    input {
        width: 100%;
        padding: 0.8rem;
        background: #1e2a3a;
        border: 1px solid #ffaa44;
        border-radius: 8px;
        color: #fff;
        transition: 0.3s;
    }
    input:focus {
        outline: none;
        border-color: #2ecc71;
        box-shadow: 0 0 8px #2ecc71;
    }
    button {
        width: 100%;
        background: #ffaa44;
        color: #0a1a24;
        border: none;
        padding: 0.8rem;
        border-radius: 8px;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }
    button:hover {
        background: #ffcc66;
        transform: translateY(-2px);
    }
    button:disabled {
        background: #888;
        cursor: not-allowed;
    }
    .error {
        background: rgba(231,76,60,0.2);
        border-left: 4px solid #e74c3c;
        padding: 0.8rem;
        margin-bottom: 1rem;
        border-radius: 8px;
    }
</style>

<div class="login-container">
    <h2><i class="fas fa-university"></i> Banker Login</h2>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" id="loginForm">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" value="<?= htmlspecialchars($username_entered) ?>" required <?= $is_locked ? 'disabled' : '' ?>>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required <?= $is_locked ? 'disabled' : '' ?>>
        </div>
        <button type="submit" <?= $is_locked ? 'disabled' : '' ?>>Login</button>
    </form>
</div>

<script>
    <?php if ($is_locked): ?>
    let remaining = <?= $remaining ?>;
    const form = document.getElementById('loginForm');
    const inputs = form.querySelectorAll('input, button');
    const interval = setInterval(() => {
        remaining--;
        if (remaining <= 0) {
            clearInterval(interval);
            inputs.forEach(el => el.disabled = false);
            const errDiv = document.querySelector('.error');
            if (errDiv) errDiv.innerHTML = '';
        }
    }, 1000);
    <?php endif; ?>
</script>



































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































<!-- Test credentials (Theese are the test credentials for the banker accounts i hope i dont forget to remove them and if i somehow forget ill ask the DBAdmin to remove this user soon so we dont get hacker): banker_test / banker_test -->

<?php require_once 'includes/footer.php'; ?>
