<?php
session_start();
$pageTitle = "Banker Portal";
require_once 'includes/header.php';
require_once 'db_connect.php';

$is_logged_in = isset($_SESSION['banker_id']) && $_SESSION['role'] === 'banker';

// Статистики (за всички банкери – виждат общи данни)
$userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$transactionCount = $pdo->query("SELECT COUNT(*) FROM transactions")->fetchColumn();
$frozenAccounts = $pdo->query("SELECT COUNT(*) FROM accounts WHERE frozen = 1")->fetchColumn();
?>

<style>
    .banker-hero {
        background: linear-gradient(135deg, #1a2a3a 0%, #0f1a24 100%);
        border-radius: 20px;
        padding: 3rem 2rem;
        margin-bottom: 2rem;
        text-align: center;
        border: 1px solid #ffaa44;
    }
    .banker-hero h1 {
        font-size: 2.5rem;
        color: #ffaa44;
    }
    .stat-card-banker {
        background: rgba(26,42,58,0.8);
        backdrop-filter: blur(8px);
        border-radius: 15px;
        padding: 1.5rem;
        text-align: center;
        transition: 0.3s;
        border: 1px solid #ffaa44;
    }
    .stat-card-banker:hover {
        transform: translateY(-5px);
        border-color: #2ecc71;
        box-shadow: 0 0 15px rgba(255,170,68,0.3);
    }
    .stat-number {
        font-size: 2rem;
        font-weight: bold;
        color: #ffaa44;
    }
    .gold-btn {
        background: #ffaa44;
        color: #0a1a24;
    }
    .gold-btn:hover {
        background: #ffcc66;
    }
</style>

<div class="banker-hero">
    <h1><i class="fas fa-university"></i> MegaBank Banker Portal</h1>
    <p>Secure internal access for bank employees. Manage customer accounts, monitor transactions, and freeze/unfreeze accounts.</p>
    <?php if (!$is_logged_in): ?>
        <a href="login.php" class="btn gold-btn" style="margin-top: 1rem;">Access Portal</a>
    <?php else: ?>
        <a href="dashboard.php" class="btn gold-btn" style="margin-top: 1rem;">Go to Dashboard</a>
    <?php endif; ?>
</div>

<div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
    <div class="stat-card-banker">
        <div class="stat-number"><?= number_format($userCount) ?></div>
        <div>Total Customers</div>
    </div>
    <div class="stat-card-banker">
        <div class="stat-number"><?= number_format($transactionCount) ?></div>
        <div>Total Transactions</div>
    </div>
    <div class="stat-card-banker">
        <div class="stat-number"><?= number_format($frozenAccounts) ?></div>
        <div>Frozen Accounts</div>
    </div>
</div>

<div class="card" style="background: rgba(26,42,58,0.6);">
    <h3>Banker Privileges</h3>
    <ul>
        <li>✅ View all customer profiles and balances</li>
        <li>✅ Freeze / unfreeze any account</li>
        <li>✅ Edit customer personal information</li>
        <li>✅ Monitor all transactions in real time</li>
        <li>🔒 Access restricted to authorized personnel only</li>
    </ul>
</div>

<div class="card" style="background: rgba(26,42,58,0.6);">
    <h3>System Status</h3>
    <p><strong>Last security audit:</strong> <?= date('d.m.Y') ?></p>
    <p><strong>Active sessions:</strong> <span id="activeSessions">Loading...</span></p>
    <p><strong>Pending reviews:</strong> 3</p>
</div>

<script>
    
    document.getElementById('activeSessions').innerText = Math.floor(Math.random() * 50) + 10;
</script>

<?php require_once 'includes/footer.php'; ?>
